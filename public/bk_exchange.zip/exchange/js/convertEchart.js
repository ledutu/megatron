function showChart(data,_t) {
	var data = splitData(data);
	var KNAME, data;
	var Zstart = window.innerWidth <= 768 ? 40 : 15;
	var Zend = 100;
	var MA1 = 0,
		MA2 = 0,
		MA3 = 0,
		MA4 = 0,
		MA5 = 0,
		MA6 = 0;
	var color1 = "#6ABD45";
	var color2 = "#BE1E2D";
	function readtime(data,time){
		if(time >= 60){
			return (parseInt(data.slice(0,2))+1)+":00";
		}else if(time< 10){
			return data.slice(0,2)+":0"+time;
		}
		return data.slice(0,2)+":"+time;
		// else if( time >= 31 && time <= 59){
		// 	return "00:"+ (60-time < 10?"0"+(60-time):(60-time));
		// }
		// else if(time <=30){
		// 	return "00:"+ (30-time < 10?"0"+(30-time):(30-time));
		// }
	}
	KNAME = 'BTCEUSDT';



	var PosK = document.getElementById('Poskdata')
	var PosMA = document.getElementById('Posmadata')
	var PosVolSelect = document.getElementById('Posvoldata');
	var optionSelect = document.getElementById('Setoption');



	function splitData(rawData) {
		var datas = [];
		var times = [];
		var vols = [];
		for (var i = 0; i < rawData.length; i++) {
			datas.push(rawData[i]);
			times.push(rawData[i].splice(0, 1)[0]);
			vols.push(rawData[i][4]);
		}
		return {
			datas: datas,
			times: times,
			vols: vols,
		};
	}

	function AutoSetMALabel() {
		var mapush = [];
		if (MA1 !== 0) {
			mapush.push('MA' + MA1[1]);
		}
		if (MA2 !== 0) {
			mapush.push('MA' + MA2[1]);
		}
		if (MA3 !== 0) {
			mapush.push('MA' + MA3[1]);
		}
		if (MA4 !== 0) {
			mapush.push('MA' + MA4[1]);
		}
		if (MA5 !== 0) {
			mapush.push('MA' + MA5[1]);
		}
		if (MA6 !== 0) {
			mapush.push('MA' + MA6[1]);
		}
		//console.log(MA2[1]) 
		return mapush
	}

	function MA(dayCount, datas, field) {
		var ma, i, l, j, sum;
		ma = [];
		//判断不放在循环内，提升性能
		if (field) {
			//有字段配置
			for (i = 0, l = datas.length; i < l; i++) {
				if (i < dayCount - 1) {
					ma.push(NaN);
					continue;
				}
				sum = 0;
				for (j = 0; j < dayCount; j++) {
					sum += datas[i - j][field];
				}
				ma.push(sum / dayCount);
			}
		} else {
			//无字段配置
			for (i = 0, l = datas.length; i < l; i++) {
				if (i < dayCount) {
					ma.push(NaN);
					continue;
				}
				sum = 0;
				for (j = 0; j < dayCount; j++) {
					sum += datas[i - j];
				}
				ma.push(sum / dayCount);
			}
		}
		return [ma, dayCount];
	}

	function EMA(n, datas, field) {
		var i, l, ema, a;
		a = 2 / (n + 1);
		if (field) {
			//二维数组
			ema = [datas[0][field]];
			for (i = 1, l = datas.length; i < l; i++) {
				ema.push((a * datas[i][field] + (1 - a) * ema[i - 1]).toFixed(4));
			}
		} else {
			//普通一维数组
			ema = [datas[0]];
			for (i = 1, l = datas.length; i < l; i++) {
				ema.push((a * datas[i] + (1 - a) * ema[i - 1]).toFixed(4));
			}
		}
		return ema;
	}

	MA1 = MA(3, data.datas, 1);
	MA2 = MA(5, data.datas, 1);
	// MA3 = MA(10, data.datas, 1);

	var highlab = [40, 0], lowlab = [-40, 0];

	var option = {
		responsive: true,
		maintainAspectRatio: false,
		"tooltip": {
			"show": true,
			"trigger": "axis",
			"triggerOn": "mousemove|click",
			"axisPointer": {
				"type": "cross"
			},
			/*
						"formatter": function (params) {
							var datas;
							if (params.length > 0) {
								PosSelect(params)
							}
						},
			*/
		},
		"xAxis": [{
			"show": true,
			"scale": true,
			"nameGap": 15,
			"gridIndex": 0,
			"splitNumber": 5,
			"axisLine": {
				"lineStyle": {
					"color": '#4a657a'
				}
			},
			"axisLabel": {
				"show": false
			},
			"axisTick": {
				"show": false
			},
			"data": data.times,
			"axisPointer": {
				"label": {
					"show": false,
				}
			}, //主图禁用下标显示
		},
		{
			"show": true,
			"scale": true,
			"nameGap": 15,
			"gridIndex": 1,
			"splitNumber": 5,
			"axisLabel": {
				"show": false
			},
			"axisTick": {
				"show": false
			},
			"data": data.times,
			"axisPointer": {
				"label": {
					"show": false,
				}
			}, //附图1禁用下标显示
		},
		{
			"show": true,
			"scale": true,
			"gridIndex": 2,
			"splitNumber": 5,
			"axisLine": {
				"lineStyle": {
					"color": '#4a657a'
				}
			},
			"axisLabel": {
				"textStyle": {
					"color": '#fff'
				}
			},
			"data": data.times,
		},
		{
			"gridIndex": 3,
			"show": false,
			"type": "value",

		}
		],
		"yAxis": [{
			"position": "right",
			"scale": true,
			"gridIndex": 0,
			"axisLine": {
				"show": false,
				"lineStyle": {
					"color": '#ccc'
				}
			},
			"axisLabel": {
				"show": true,
				"textStyle": {
					"color": '#fff'
				}
			},
			"splitLine": {
				"show": true,
				"lineStyle": {
					"color": 'rgb(0 0 0 / 0.1)',
					width: 1
					//"type": 'dashed'
				}
			},
		},
		{
			"position": "right",
			"gridIndex": 1,
			"splitNumber": 2,
			"minInterval": 0,
			"axisLine": {
				"lineStyle": {
					"color": '#4a657a'
				}
			},
			"axisLabel": {

				"textStyle": {
					"color": '#fff'
				}
			},
			"splitLine": {
				"show": false,
				"lineStyle": {
					"color": '4a657a',
					//"type": 'dashed'
				}
			},
		},
		{
			"position": "right",
			"gridIndex": 2,
			"splitNumber": 3,
			"show": false,
			"axisLine": {
				"lineStyle": {
					"color": '#fff'
				}
			},
			"axisLabel": {
				"show": false,
				"textStyle": {
					"color": '#fff'
				}
			},
			"splitLine": {
				"show": false,
				"lineStyle": {
					"color": '4a657a',
					//"type": 'dashed'
				}
			},
		},
		{
			"gridIndex": 3,
			"show": false,
			"type": "category",
			"axisLabel": {
				"showMinLabel": false,
				"formatter": function (val) {
					return '￥' + val
				},
				"textStyle": {
					"color": '#fff'
				}
			},
			"splitLine": {
				"show": false,
				"lineStyle": {
					"color": '#fff',
					//"type": 'dashed'
				}
			},
			"axisLine": {
				"show": false,
				"lineStyle": {
					"color": 'transparent'
				}
			},
		}
		],
		"title": {
			"text": "BTCUSDT",
			"color": '#fff',
			"show": true,
			"textStyle": {
                "color": "#fff"
            }
		},
		"dataZoom": [{
			"show": false,
			"type": "",
			"start": Zstart,
			"end": Zend,
			"xAxisIndex": [
				0,
				0
			],
		},
		{
			"show": false,
			"type": "slider",
			"start": Zstart,
			"end": Zend,
			"xAxisIndex": [
				0,
				1
			],
		},
		{
			"show": false,
			"type": "slider",
			"start": Zstart,
			"end": Zend,
			"xAxisIndex": [
				0,
				2
			],
		},
		{
			"show": false,
		}
		],

		"axisPointer": {
			"show": true,
			"type": "line",
			"link": [{
				"xAxisIndex": "all"
			}]
		},
		"toolbox": {
			"Show": false
		},
		"series": [{
			"right": "30%",
			"padding": 5,
			"z":-1,
			"type": "candlestick",
			"name": "BTCUSDT",
			"xAxisIndex": 0,
			"yAxisIndex": 0,
			"data": data.datas,
			"markPoint": {
				"symbol": 'circle',
				"symbolSize": function (value, param) {
					let size = 13
					if (param.name === 'Highest price' || param.name === 'Lowest price') {
						size = 0.1
					}
					return size
				},
				"label": {
					"zlevel":300,
					"show": true,
					"fontSize": 12,
					"color": '#fff',
					"formatter": function (param) {
						let val = ''
						if (param.name === 'punctuation') {
							val = param.value
						} else if (param.name === 'Lowest price') {
							val = param.value + ' →'
							// lowlab = [-40,0]
						} else if (param.name === 'Highest price') {
							val =param.value + ' →' 
							// ←
							// highlab = [-40,0]
						}
						return val
					}
				},
				"data": [{
					"name": "Highest price",
					"type": "max",
					"valueDim": 'highest',
					"symbolOffset": lowlab,
					"itemStyle": {
						"color": color2,
					},
				},
				{
					"name": "Lowest price",
					"type": "min",
					"valueDim": 'lowest',
					"symbolOffset": lowlab,
					"itemStyle": {
						"color": "rgb(41,60,85)",
					}
				}
				]
			},
			"markLine": {
				"zlevel":10000,
				"symbol": "",
				"data": [{
					"yAxis": data.datas[data.datas.length - 1][1],
					"zlevel":10000,
					"label": {
						formatter: function (d) {
							return data.datas[data.datas.length - 1][1].toFixed(2).replace(/\d(?=(\d{3})+\.)/g, "$&,") +
								'\n'
								+ readtime(data.times[data.times.length - 1],_t);
						},
						"zlevel":10000,
						"show": true,
						"color": data.datas[data.datas.length - 1][1] - data.datas[data.datas.length - 2][1] == 0 ? "black" :"#fff",
						"position": window.innerWidth <= 768 ? "insideMiddleBottom" : "center",
						"z-index": 1050,
						"padding": 2,
						"borderRadius": 5,
						"backgroundColor": data.datas[data.datas.length - 1][1] - data.datas[data.datas.length - 2][1] == 0 ? "orange" : data.datas[data.datas.length - 1][1] - data.datas[data.datas.length - 2][1] > 0 ? color1 : color2,
					},
					"lineStyle": {
						"color": data.datas[data.datas.length - 1][1] - data.datas[data.datas.length - 2][1] == 0 ? "orange" : data.datas[data.datas.length - 1][1] - data.datas[data.datas.length - 2][1] > 0 ? color1 : color2,
						"width": 1,
						"type": "dashed"
					},
				},]
			},
			"itemStyle": {
				"color": color1,
				"color0": color2,
				"borderColor": color1,
				"borderColor0": color2
			}
		},
		{
			"type": "line",
			"name": AutoSetMALabel()[0],
			"data": MA1[0],
			smooth: true,
			showSymbol: false,
			lineStyle: {
				width: 1,
				color: "red"
			}
		},
		{
			"type": "line",
			"name": AutoSetMALabel()[1],
			"data": MA2[0],
			smooth: true,
			showSymbol: false,
			lineStyle: {
				width: 1,
				color: "blue"
			}
		},
		{
			"type": "line",
			"name": AutoSetMALabel()[2],
			"data": MA3[0],
			smooth: true,
			showSymbol: false,
			lineStyle: {
				width: 1,
				color: "rgb(0 118 255)"
			}
		},
		{
			"type": "line",
			"name": AutoSetMALabel()[3],
			"data": MA4[0],
			smooth: true,
			showSymbol: false,
			lineStyle: {
				width: 1
			}
		},
		{
			"type": "line",
			"name": AutoSetMALabel()[4],
			"data": MA5[0],
			smooth: true,
			showSymbol: false,
			lineStyle: {
				width: 1
			}
		},
		{
			"type": "line",
			"name": AutoSetMALabel()[5],
			"data": MA6[0],
			smooth: true,
			showSymbol: false,
			lineStyle: {
				width: 1
			}
		},
		{
			"type": "bar",
			"name": "Volume",
			"xAxisIndex": 1,
			"yAxisIndex": 1,
			"data": data.vols,
			"barCategoryGap": "40%",
			"itemStyle": {
				"normal": {
					"color": function (params) {
						var colorList;

						if (data.datas[params.dataIndex][1] > data.datas[params.dataIndex][0]) {
							colorList = color1;
						} else {
							colorList = color2;
						}
						return colorList;
					},
				}
			},
			"markLine": {
				"symbol": "",
				"data": [{
					"yAxis": data.vols[data.vols.length - 1],

					"label": {
						formatter: function (d) {
							return data.vols[data.vols.length - 1].toFixed(2).replace(/\d(?=(\d{3})+\.)/g, "$&,") +
								'\n'
								+ readtime(data.times[data.times.length - 1],_t);
						},
						"show": true,
						"color": data.datas[data.datas.length - 1][1] - data.datas[data.datas.length - 2][1] == 0 ? "black" :"#fff",
						"position": "center",
						"padding": 3,
						"borderRadius": 5,
						"backgroundColor": data.datas[data.vols.length - 1] - data.datas[data.vols.length - 2] == 0 ? "orange" : data.datas[data.datas.length - 1][1] - data.datas[data.datas.length - 2][1] > 0 ? color1 : color2,
					},
					"lineStyle": {
						"color": data.datas[data.vols.length - 1] - data.datas[data.vols.length - 2] == 0 ? "orange" : data.datas[data.datas.length - 1][1] - data.datas[data.datas.length - 2][1] > 0 ? color1 : color2,
						"width": 1,
						"type": "dashed"
					},
				},]
			}
		},
		{
			"type": "line",
			"xAxisIndex": 3,
			"yAxisIndex": 3,
			"areaStyle": {
				"color": 'red',
				"opacity": .2,
			},
		},
		{
			"type": "line",
			"xAxisIndex": 3,
			"yAxisIndex": 3,
			"areaStyle": {
				"color": 'red',
				"opacity": .2,
			},
		}
		],
		"legend": [{
			"textStyle": {
				"color": '#fff'
			},
			"data": [AutoSetMALabel()[0], AutoSetMALabel()[1], AutoSetMALabel()[2]],
			"color": 'red',
			"show": true,
			"padding": 5,
			"itemGap": 10,
			"itemWidth": 20,
			"itemHeight": 14,
			"top": "0%",
			"right":  window.innerWidth <= 475 ? "0px" : "10%",
			"margin": "auto"

		},
		{
			"show": false,
			"padding": 5,
			"itemGap": 10,
			"itemWidth": 25,
			"itemHeight": 14
		}
		],

		"grid": [{
			"show": false,
			"top": "10%",
			"left": "0.5%",
			"right": "5%",
			"width": window.innerWidth <= 800 ? window.innerWidth <= 480 ? window.innerWidth <= 380? "80%":"87%" : "91%" : "",
			"bottom": "25%",
			"borderColor": 'red',
		},
		{
			"show": false,
			"left": "0.5%",
			"right": "5%",
			"top": "83%",
			"width": window.innerWidth <= 800 ? window.innerWidth <= 480 ? "80%" : "91%" : "",
			"bottom": window.innerWidth <= 768 ? "30px" : window.innerHeight <= 500 ? "10%" : "30px",
			"borderColor": 'blue',
		},
		{
			"show": false,
			"left": "0.5%",
			"top": "75%",
			"right": "5%",
			"bottom": "30px",
			"borderColor": 'green',
		},
		{
			"left": "92%",
			"right": "0%",
			// "height": "60%",
			// "bottom":"35%",
			"borderColor": 'transparent',
		}
		]
	};
	var chartContainer = document.getElementById('MainCharts');
	var myChart = echarts.init(chartContainer);
	myChart.setOption(option);

	window.onresize = function () {
		//location.reload();
		myChart.resize();
	}
}


