  
	function convertd1(_d1, _class){
      var aaa = _d1.buy/(_d1.buy+_d1.sell);
      var text = 'Strong Buy';
      $('.'+_class+' .value-sell').html(_d1.sell);
      $('.'+_class+' .value-buy').html(_d1.buy);
      if(aaa>0.5){
          text = 'Strong Sell';
      }

          var gua_option_1 = {
            tooltip: {
              formatter: "{b}{c}"
            },
            series: [{
              tooltip: {
                show: false
              },
              "name": 'wrap',
              "type": 'pie',
              "hoverAnimation": false,
              "legendHoverLink": false,
              center: ['50%', '60%'],
              "radius": ['0%', '7%'],
              "z": 5,
              "label": {
                "normal": {
                  "show": false,
                  "position": 'center'
                },
                "emphasis": {
                  "show": false
                }
              },
              "labelLine": {
                "normal": {
                  "show": false
                }
              }
            }, {
              tooltip: {
                show: false
              },
              "name": 'wrap',
              "type": 'pie',
              "hoverAnimation": false,
              "legendHoverLink": false,
              center: ['50%', '60%'],
              "radius": ['6%', '8%'],
              "z": 5,
              "label": {
                "normal": {
                  "show": false,
                  "position": 'center'
                },
                "emphasis": {
                  "show": false
                }
              },
              "labelLine": {
                "normal": {
                  "show": false
                }
              }
            }, {
              tooltip: {
                show: false
              },
              name: '',
              type: 'gauge',
              radius: '68%',
              z: 1,
              min: 0,
              max: 1,
              center: ['50%', '60%'],
              splitNumber: 5, //刻度数量
              startAngle: 180,
              endAngle: 0,
              axisLine: {
                show: true,
                lineStyle: {
                  width: 5,
                  color: [
                    [0.12, '#ff0000'],
                    [0.35, '#ed6d6d'],
                    [0.63, '#fff'],
                    [0.8, '#9cffc7'],
                    [1, '#00af4b'],

                  ]
                }
              }, //仪表盘轴线
              axisLabel: {
                show: false
              }, //刻度标签。
              axisTick: {
                show: false,
                lineStyle: {
                  color: 'auto',
                  width: 0
                },
                length: -15
              }, //刻度样式
              splitLine: {
                show: false,
                length: 0,
                lineStyle: {
                  color: 'auto',
                  width: 2
                }
              }, //分隔线样式
              detail: {
                show: false
              },
              pointer: {
                show: false
              }
            },
            {
              name: '',
              type: 'gauge',
              show: false,
              radius: '70%',
              min: 0,
              max: 1,
              center: ['50%', '60%'],
              label:{
                formatter: function (params) {
                  var value = params.toFixed(2)

                  if (value == 0.00) {
                    return 'STRONG ' + '\n' +
                      'SELL'
                  } else if (value == 0.25) {
                    return 'SELL'
                  } else if (value == 0.50) {
                    return 'NEUTRAL'
                  } else if (value == 0.75) {
                    return 'BUY'
                  } else if (value == 1.00) {
                    return 'STRONG' + '\n' + 'BUY'
                  } else {
                    return ''
                  }
                }
              },
              data: [{
                value: aaa,
                name: text
              }],
              splitNumber: 12, //刻度数量
              startAngle: 180,
              endAngle: 0,
              z: 5,
              axisLine: {
                show: false,
                lineStyle: {
                  width: 0,
                  color: [
                    [0.12, '#ff0000'],
                    [0.35, '#ed6d6d'],
                    [0.63, '#fff'],
                    [0.8, '#9cffc7'],
                    [1, '#00af4b'],

                  ]
                }
              }, //仪表盘轴线
              axisLabel: {
                show: true,
                color: '#fff',
                fontSize: 10,
                distance: -60,
                padding: [10, 0, 0, 0],
                formatter: function (params) {
                  var value = params.toFixed(2)

                  if (value == 0.00) {
                    return 'STRONG ' + '\n' + '\t\t\t'+
                      'SELL'
                  } else if (value == 0.25) {
                    return 'SELL'
                  } else if (value == 0.50) {
                    return 'NEUTRAL'
                  } else if (value == 0.75) {
                    return 'BUY'
                  } else if (value == 1.00) {
                    return 'STRONG' + '\n' + 'BUY'+ '\t\t\t'
                  } else {
                    return ''
                  }
                }
              }, //刻度标签。
              axisTick: {
                splitNumber: 10,
                show: false,
                lineStyle: {
                  color: 'auto',
                  width: 2
                },
                length: 20,
              }, //刻度样式
              splitLine: {
                show: false,
                length: 25,
                lineStyle: {
                  color: 'auto',
                  width: 5
                }
              }, //分隔线样式

              "itemStyle": {
                "normal": {
                  "color": "#24D8E7" //指针颜色
                }
              },
              pointer: {
                width: 2,
                length: '90%'
              },
              detail: {
                formatter: function (params) {
                  return (params * 100).toFixed(0) + '%'
                },
                fontSize: 15,
                color: "#fff",
                offsetCenter: ['0%', '-35%'],
                show:false
              },
              title: {
                offsetCenter: ['0', '15%'],
                fontSize: 15,
                color: "#fff",
                show: true
              },
            }]
          };
          var gua_container_1 = document.getElementById('gua_1');
        var gua_1 = echarts.init(gua_container_1);
        gua_1.setOption(gua_option_1);

        window.onresize = function () {
          gua_1.resize();
        }
    }

	
function convertd2(_d2, _class){
      var aaa = _d2.buy/(_d2.buy+_d2.sell);
		console.log(_d2, _class);
      var text = 'Strong Buy';
      $('.qua_2 .value-sell').html(_d2.sell);
      $('.qua_2 .value-buy').html(_d2.buy);
      if(aaa>0.5){
          text = 'Strong Sell';
      }

          var gua_option_2 = {
            tooltip: {
              formatter: "{b}{c}"
            },
            series: [{
              tooltip: {
                show: false
              },
              "name": 'wrap',
              "type": 'pie',
              "hoverAnimation": false,
              "legendHoverLink": false,
              center: ['50%', '60%'],
              "radius": ['0%', '7%'],
              "z": 5,
              "label": {
                "normal": {
                  "show": false,
                  "position": 'center'
                },
                "emphasis": {
                  "show": false
                }
              },
              "labelLine": {
                "normal": {
                  "show": false
                }
              }
            }, {
              tooltip: {
                show: false
              },
              "name": 'wrap',
              "type": 'pie',
              "hoverAnimation": false,
              "legendHoverLink": false,
              center: ['50%', '60%'],
              "radius": ['6%', '8%'],
              "z": 5,
              "label": {
                "normal": {
                  "show": false,
                  "position": 'center'
                },
                "emphasis": {
                  "show": false
                }
              },
              "labelLine": {
                "normal": {
                  "show": false
                }
              }
            }, {
              tooltip: {
                show: false
              },
              name: '',
              type: 'gauge',
              radius: '68%',
              z: 1,
              min: 0,
              max: 1,
              center: ['50%', '60%'],
              splitNumber: 5, //刻度数量
              startAngle: 180,
              endAngle: 0,
              axisLine: {
                show: true,
                lineStyle: {
                  width: 5,
                  color: [
                    [0.12, '#ff0000'],
                    [0.35, '#ed6d6d'],
                    [0.63, '#fff'],
                    [0.8, '#9cffc7'],
                    [1, '#00af4b'],

                  ]
                }
              }, //仪表盘轴线
              axisLabel: {
                show: false
              }, //刻度标签。
              axisTick: {
                show: false,
                lineStyle: {
                  color: 'auto',
                  width: 0
                },
                length: -15
              }, //刻度样式
              splitLine: {
                show: false,
                length: 0,
                lineStyle: {
                  color: 'auto',
                  width: 2
                }
              }, //分隔线样式
              detail: {
                show: false
              },
              pointer: {
                show: false
              }
            },
            {
              name: '',
              type: 'gauge',
              show: false,
              radius: '70%',
              min: 0,
              max: 1,
              center: ['50%', '60%'],
              label:{
                formatter: function (params) {
                  var value = params.toFixed(2)

                  if (value == 0.00) {
                    return 'STRONG ' + '\n' +
                      'SELL'
                  } else if (value == 0.25) {
                    return 'SELL'
                  } else if (value == 0.50) {
                    return 'NEUTRAL'
                  } else if (value == 0.75) {
                    return 'BUY'
                  } else if (value == 1.00) {
                    return 'STRONG' + '\n' + 'BUY'
                  } else {
                    return ''
                  }
                }
              },
              data: [{
                value: aaa,
                name: text
              }],
              splitNumber: 12, //刻度数量
              startAngle: 180,
              endAngle: 0,
              z: 5,
              axisLine: {
                show: false,
                lineStyle: {
                  width: 0,
                  color: [
                    [0.12, '#ff0000'],
                    [0.35, '#ed6d6d'],
                    [0.63, '#fff'],
                    [0.8, '#9cffc7'],
                    [1, '#00af4b'],

                  ]
                }
              }, //仪表盘轴线
              axisLabel: {
                show: true,
                color: '#fff',
                fontSize: 10,
                distance: -60,
                padding: [10, 0, 0, 0],
                formatter: function (params) {
                  var value = params.toFixed(2)

                  if (value == 0.00) {
                    return 'STRONG ' + '\n' + '\t\t\t'+
                      'SELL'
                  } else if (value == 0.25) {
                    return 'SELL'
                  } else if (value == 0.50) {
                    return 'NEUTRAL'
                  } else if (value == 0.75) {
                    return 'BUY'
                  } else if (value == 1.00) {
                    return 'STRONG' + '\n' + 'BUY'+ '\t\t\t'
                  } else {
                    return ''
                  }
                }
              }, //刻度标签。
              axisTick: {
                splitNumber: 10,
                show: false,
                lineStyle: {
                  color: 'auto',
                  width: 2
                },
                length: 20,
              }, //刻度样式
              splitLine: {
                show: false,
                length: 25,
                lineStyle: {
                  color: 'auto',
                  width: 5
                }
              }, //分隔线样式

              "itemStyle": {
                "normal": {
                  "color": "#24D8E7" //指针颜色
                }
              },
              pointer: {
                width: 2,
                length: '90%'
              },
              detail: {
                formatter: function (params) {
                  return (params * 100).toFixed(0) + '%'
                },
                fontSize: 15,
                color: "#fff",
                offsetCenter: ['0%', '-35%'],
                show:false
              },
              title: {
                offsetCenter: ['0', '15%'],
                fontSize: 15,
                color: "#fff",
                show: true
              },
            }]
          };
         var gua_container_2 = document.getElementById('gua_2');
        var gua_2 = echarts.init(gua_container_2);
        gua_2.setOption(gua_option_2);

        window.onresize = function () {
          gua_2.resize();
        }
    }
function convertd3(_d3, _class){
      var aaa = _d3.buy/(_d3.buy+_d3.sell);
      var text = 'Strong Buy';
      $('.qua_3 .value-sell').html(_d3.sell);
      $('.qua_3 .value-buy').html(_d3.buy);
      if(aaa>0.5){
          text = 'Strong Sell';
      }

          var gua_option_3 = {
            tooltip: {
              formatter: "{b}{c}"
            },
            series: [{
              tooltip: {
                show: false
              },
              "name": 'wrap',
              "type": 'pie',
              "hoverAnimation": false,
              "legendHoverLink": false,
              center: ['50%', '60%'],
              "radius": ['0%', '7%'],
              "z": 5,
              "label": {
                "normal": {
                  "show": false,
                  "position": 'center'
                },
                "emphasis": {
                  "show": false
                }
              },
              "labelLine": {
                "normal": {
                  "show": false
                }
              }
            }, {
              tooltip: {
                show: false
              },
              "name": 'wrap',
              "type": 'pie',
              "hoverAnimation": false,
              "legendHoverLink": false,
              center: ['50%', '60%'],
              "radius": ['6%', '8%'],
              "z": 5,
              "label": {
                "normal": {
                  "show": false,
                  "position": 'center'
                },
                "emphasis": {
                  "show": false
                }
              },
              "labelLine": {
                "normal": {
                  "show": false
                }
              }
            }, {
              tooltip: {
                show: false
              },
              name: '',
              type: 'gauge',
              radius: '68%',
              z: 1,
              min: 0,
              max: 1,
              center: ['50%', '60%'],
              splitNumber: 5, //刻度数量
              startAngle: 180,
              endAngle: 0,
              axisLine: {
                show: true,
                lineStyle: {
                  width: 5,
                  color: [
                    [0.12, '#ff0000'],
                    [0.35, '#ed6d6d'],
                    [0.63, '#fff'],
                    [0.8, '#9cffc7'],
                    [1, '#00af4b'],

                  ]
                }
              }, //仪表盘轴线
              axisLabel: {
                show: false
              }, //刻度标签。
              axisTick: {
                show: false,
                lineStyle: {
                  color: 'auto',
                  width: 0
                },
                length: -15
              }, //刻度样式
              splitLine: {
                show: false,
                length: 0,
                lineStyle: {
                  color: 'auto',
                  width: 2
                }
              }, //分隔线样式
              detail: {
                show: false
              },
              pointer: {
                show: false
              }
            },
            {
              name: '',
              type: 'gauge',
              show: false,
              radius: '70%',
              min: 0,
              max: 1,
              center: ['50%', '60%'],
              label:{
                formatter: function (params) {
                  var value = params.toFixed(2)

                  if (value == 0.00) {
                    return 'STRONG ' + '\n' +
                      'SELL'
                  } else if (value == 0.25) {
                    return 'SELL'
                  } else if (value == 0.50) {
                    return 'NEUTRAL'
                  } else if (value == 0.75) {
                    return 'BUY'
                  } else if (value == 1.00) {
                    return 'STRONG' + '\n' + 'BUY'
                  } else {
                    return ''
                  }
                }
              },
              data: [{
                value: aaa,
                name: text
              }],
              splitNumber: 12, //刻度数量
              startAngle: 180,
              endAngle: 0,
              z: 5,
              axisLine: {
                show: false,
                lineStyle: {
                  width: 0,
                  color: [
                    [0.12, '#ff0000'],
                    [0.35, '#ed6d6d'],
                    [0.63, '#fff'],
                    [0.8, '#9cffc7'],
                    [1, '#00af4b'],

                  ]
                }
              }, //仪表盘轴线
              axisLabel: {
                show: true,
                color: '#fff',
                fontSize: 10,
                distance: -60,
                padding: [10, 0, 0, 0],
                formatter: function (params) {
                  var value = params.toFixed(2)

                  if (value == 0.00) {
                    return 'STRONG ' + '\n' + '\t\t\t'+
                      'SELL'
                  } else if (value == 0.25) {
                    return 'SELL'
                  } else if (value == 0.50) {
                    return 'NEUTRAL'
                  } else if (value == 0.75) {
                    return 'BUY'
                  } else if (value == 1.00) {
                    return 'STRONG' + '\n' + 'BUY'+ '\t\t\t'
                  } else {
                    return ''
                  }
                }
              }, //刻度标签。
              axisTick: {
                splitNumber: 10,
                show: false,
                lineStyle: {
                  color: 'auto',
                  width: 2
                },
                length: 20,
              }, //刻度样式
              splitLine: {
                show: false,
                length: 25,
                lineStyle: {
                  color: 'auto',
                  width: 5
                }
              }, //分隔线样式

              "itemStyle": {
                "normal": {
                  "color": "#24D8E7" //指针颜色
                }
              },
              pointer: {
                width: 2,
                length: '90%'
              },
              detail: {
                formatter: function (params) {
                  return (params * 100).toFixed(0) + '%'
                },
                fontSize: 15,
                color: "#fff",
                offsetCenter: ['0%', '-35%'],
                show:false
              },
              title: {
                offsetCenter: ['0', '15%'],
                fontSize: 15,
                color: "#fff",
                show: true
              },
            }]
          };
        
        var gua_container_3 = document.getElementById('gua_3');
        var gua_3 = echarts.init(gua_container_3);
        gua_3.setOption(gua_option_3);

        window.onresize = function () {
          gua_3.resize();
        }
    }