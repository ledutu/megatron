var swiper = new Swiper('#section-4 .swiper-container', {
  effect: 'coverflow',
  grabCursor: true,
  centeredSlides: 1,
  slidesPerView: 'auto',
  coverflowEffect: {
    rotate: 40,
    stretch: 0,
    depth: 100,
    modifier: -1,
    slideShadows: false,
  },
  spaceBetween: 30,
  grabCursor: true,
  loop: true,
  autoplay: {
    delay: 1000,
  },
  breakpoints: {
    480: {
      slidesPerView: 1,
      spaceBetween: 20,
    },
    640: {
      slidesPerView: 2,
      spaceBetween: 20,
    },
    768: {
      slidesPerView: 2,
      spaceBetween: 40,
    },
    1024: {
      slidesPerView: 3,
      spaceBetween: 50,
    },
  }
});
var swiper = new Swiper('#section-5 .swiper-container', {
  effect: 'coverflow',
  grabCursor: true,
  centeredSlides: 1,
  slidesPerView: 'auto',
  coverflowEffect: {
    rotate: 20,
    stretch: 1,
    depth: 100,
    modifier:-1,
    slideShadows: false,
  },
  spaceBetween: 30,
  grabCursor: true,
  loop: true,
  autoplay: {
    delay: 4000,
    speed:1000
  },
  breakpoints: {
    480: {
      slidesPerView: 1,
      spaceBetween: 20,
    },
    640: {
      slidesPerView: 1,
      spaceBetween: 20,
    },
    768: {
      slidesPerView: 2,
      spaceBetween: 40,
    },
    1024: {
      slidesPerView: 3,
      spaceBetween: 50,
    },
  }
});

        // 2. This code loads the IFrame Player API code asynchronously.
  var tag = document.createElement('script');

  tag.src = "https://www.youtube.com/iframe_api";
  var firstScriptTag = document.getElementsByTagName('script')[0];
  firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

  // 3. This function creates an <iframe> (and YouTube player)
  //    after the API code downloads.
  var player;

  function onYouTubeIframeAPIReady() {

    player = new YT.Player('player', {
      width: '100%',
      height: '100%',
      loadPlaylist: {
        listType: 'playlist',
        list: ['CzBoDUHQRKA'],
        index: parseInt(0),
        suggestedQuality: 'small'
      },
      playerVars: {
        'autoplay': 1,
        'playsinline': 1,
        'controls': 1,
        'fs': 0,
        'iv_load_policy': 3,
        'rel': 0,
        'showinfo': 1,

      },


      events: {
        // 'onReady': onPlayerReady
      }
    });
  }
  function onPlayerReady(event) {

    event.target.playVideo();
    event.target.loadPlaylist(['CzBoDUHQRKA']);
  }

  // Select all links with hashes
$('a[href*="#"]')
// Remove links that don't actually link to anything
.not('[href="#"]')
.not('[href="#0"]')
.click(function(event) {
  // On-page links
  if (
    location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') 
    && 
    location.hostname == this.hostname
  ) {
    // Figure out element to scroll to
    var target = $(this.hash);
    target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
    // Does a scroll target exist?
    if (target.length) {
      // Only prevent default if animation is actually gonna happen
      event.preventDefault();
      $('html, body').animate({
        scrollTop: target.offset().top - 75
      }, 1000, function() {
        // Callback after animation
        // Must change focus!
        var $target = $(target);
        $target.focus();
        if ($target.is(":focus")) { // Checking if the target was focused
          return false;
        } else {
          $target.attr('tabindex','-1'); // Adding tabindex for elements not focusable
          $target.focus(); // Set focus again
        };
      });
    }
  }
});