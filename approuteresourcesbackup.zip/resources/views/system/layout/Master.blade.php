<!DOCTYPE html>
<html>
<head>
    <title>IG Trade</title>
  	<meta property="og:title" content="IG Trade">
    <meta property="og:url" content="http://igtrade.co/">
    <meta property="og:image" content="exchange/img/icon/logo_icon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="exchange/img/icon/logo_icon.png">
    <link rel="manifest" href="exchange/manifest.json">
    <base href="{{asset('')}}">
    @include('system.layout.Maincss')
    @yield('css')
</head>

<body class="exchane">
  @include('system.layout.Sidebar')
  <div class="wrap exchange-dashboard">
        @include('system.layout.Topbar')
      <div class="content container customer">
          <!-- <h2 class="page-title">BTCUSDT <small>Exchange</small></h2> -->
          @yield('content')
      </div>
      <div class="loader-wrap hiding hide">
          <i class="fa fa-circle-o-notch fa-spin"></i>
      </div>
  </div>
  @include('system.layout.Mainscripts')
  @yield('scripts')
</body>

</html>