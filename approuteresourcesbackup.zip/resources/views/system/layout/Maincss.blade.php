<link rel="stylesheet" href="exchange/css/tailwind.min.css">
<link href="exchange/css/application.css?v=<?=time()?>" rel="stylesheet">
<link href="exchange/css/customer.css?v=<?=time()?>" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@9/dist/sweetalert2.min.css" id="theme-styles">
<link href="exchange/css/layout.css?v=<?=time()?>" rel="stylesheet">
<link rel="stylesheet" href="exchange/css/fonts/font-awesome/css/all.min.css">
<script src="exchange/css/fonts/font-awesome/js/all.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
<link rel="stylesheet" href="exchange/lib/DataTables/datatables.css?v={{time()}}">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.3/toastr.min.css">
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<style>
    .grecaptcha-badge{
      	 visibility: hidden;
      }
      .toast-message{
          font-size: 15px;
          font-weight: 500;
      }
</style>
