<script src="exchange/lib/jquery/dist/jquery.min.js"></script>

<script src="exchange/lib/jquery-pjax/jquery.pjax.js"></script>
<script src="exchange/lib/bootstrap-sass/assets/javascripts/bootstrap.min.js"></script>
<script src="exchange/lib/widgster/widgster.js"></script>

<script src="exchange/js/app.js?v=1"></script>
<script src="exchange/js/settings.js?v={{time()}}"></script>

<script src="exchange/lib/slimScroll/jquery.slimscroll.min.js"></script>
<script src="exchange/lib/jquery.sparkline/index.js"></script>


<script src="exchange/lib/d3/d3.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/sweetalert2@9/dist/sweetalert2.min.js"></script>
<script src="exchange/lib/nvd3/build/nv.d3.min.js"></script>
<script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.22/js/dataTables.jqueryui.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.3/toastr.min.js"></script>
<script src="exchange/js/echarts.js?v=3"></script>
<script type="text/javascript">
  // var attr_menu;

  $(".nav.navbar-nav li.dropdown").on('click',function (e) {

    if( $(this).hasClass('open')){
      $(".nav.navbar-nav li.dropdown").removeClass('open');
    }
    else{
      $(".nav.navbar-nav li.dropdown").removeClass('open');
      $(this).addClass('open');
    }
    $(".close-history").removeClass('open');
  })
  $("#history-trads").click(function(){
    $(".close-history").addClass('open');
  })
  $(".close-history").click(function () {
    $("li.dropdown").removeClass('open');
    $(".close-history").removeClass('open');
  })
  $(document).mouseup(function (e) {
    var container = $('.dropdown .dropdown-toggle')
    if (!container.is(e.target) && container.has(e.target).length === 0) 
    {
      $(".close-history").removeClass('open');
      $(".dropdown").removeClass('open');
    }

  });

</script>
<script src="https://www.google.com/recaptcha/api.js?render=6LcTkekZAAAAAOb5kmSdwy1HFLyB4dmgiqSvQyV5"></script>
<script>
  grecaptcha.ready(function() {
      grecaptcha.execute('6LcTkekZAAAAAOb5kmSdwy1HFLyB4dmgiqSvQyV5', {action:'wallet'})
      .then(function(token) {
          $('form').append('<input type="hidden" name="token_v3" value="'+token+'">');
      });
  });
</script>

<script>
  toastr.options = {
  "closeButton": false,
  "debug": false,
  "newestOnTop": false,
  "progressBar": true,
  "positionClass": "toast-top-center",
  "preventDuplicates": false,
  "onclick": null,
  "showDuration": "300",
  "hideDuration": "1000",
  "timeOut": "5000",
  "extendedTimeOut": "1000",
  "showEasing": "swing",
  "hideEasing": "linear",
  "showMethod": "fadeIn",
  "hideMethod": "fadeOut"
}
    function Copy_link(id) {
  /* Get the text field */
  var copyText = document.getElementById(id);

  /* Select the text field */
  copyText.select();
  copyText.setSelectionRange(0, 99999); /*For mobile devices*/

  /* Copy the text inside the text field */
  document.execCommand("copy");

  /* Alert the copied text */
  toastr.success("Your Copy Success! Link:"+copyText.value)
  // alert("Copied the text: " + copyText.value);
}
</script>