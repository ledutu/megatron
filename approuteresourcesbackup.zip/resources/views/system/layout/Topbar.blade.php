<header class="page-header flex">
  <div class="navbar flex-1">
    <a href="" class="pull-left flex-1 flex justify-start self-center">
      <img class="img-logo" src="exchange/img/logo.png?v=1">
      <img class="img-logo-mobile hidden-lg" src="exchange/img/logo_mobile.png">
    </a>
    <ul class="nav navbar-nav navbar-right pull-right">
      <div class="close-history">x</div>
      <li class="dropdown btn-select-acount" data-menu="#account-menu">
        <a href="#" title="Account" id="account" class="dropdown-toggle my--subaccount" >
          <span>
            <span class="d-block white">Live Account</span>
            <span class="white d-block font-18" id="UserBalance">$0.00</span>
          </span>
        </a>
        <ul class="dropdown-menu " id="account-menu" role="menu">
          <li role="presentation" class="account-picture active">
            <a class="select_coin cursor-pointer flex" data-name="live">
              <div class="col-span-1 flex flex-col flex-1">
                <span class="d-block white white balance-name">Live Account</span>
                <span class="balance-value">$1000</span>
              </div>
            </a>
          </li>
          <li role="presentation" class="account-picture">
            <a class="select_coin cursor-pointer flex " data-name="demo">
              <div class="col-span-1 flex flex-col flex-1">
                <span class="d-block balance-name">Demo Account</span>
                <span class="balance-value">$1000</span>
              </div>
              <div class="col-span-1 flex  flex-1 justify-end">
                <button class="btn button btn-ig-1">
                  <i class="fas fa-sync-alt"></i>
                </button>
              </div>

            </a>
          </li>
        </ul>
      </li>
      <li class="dropdown btn-deposit-acount" data-menu="#deposit-menu">
        <a href="#" title="Account" class="dropdown-toggle my--subaccount" >
          <span>
            <span class="d-block ">Deposit Fast</span>
          </span>
        </a>
        <ul class="dropdown-menu fast-deposit" id="deposit-menu" role="menu">
          <form action="" method="POST">
            @csrf
            <div class="flex flex-col my-deposit">
              <div class="flex flex-col">
                <label for="" class=" white">From Main Balance</label>
                <input class="form-control amount-input" readonly />
              </div>
              <div class="flex flex-col my-deposit">
                <label for="" class=" white">Deposit Amount</label>
                <input class="form-control amount-input" name="amount" require />
              </div>
              <div class="flex flex-col my-deposit">
                <span class="white">Minimum deposit value is $11</span>
              </div>
              <div class="flex flex-col my-deposit">
                <span class="white">*Total Receive Amount</span>
                <span class="font-18 white"> $0.00</span>
              </div>
              <div class="flex flex-col my-deposit">
                <button class="button btn  btn-deposit-acount">
                  Deposit Now
                </button>
                <span class="white">*Subject to change</span>
              </div>

            </div>
          </form>
        </ul>
      </li>
      <li class="dropdown btn-setting hidden md:block" data-menu="#setting-menu">
        <a href="#" title="Account" class="dropdown-toggle my--subaccount" >
          <span>
            <span class=" flex flex-col justify-center items-center self-center"><i class="fas fa-sliders-v-square"></i>
            <span>Setting</span>  
            </span>
          </span>
        </a>
        <ul class="dropdown-menu setting-1" id="setting-menu" role="menu">
          <li role="presentation" class="account-picture active">
              <div class="col-span-1 flex flex-1">
                <span class=" white white flex-1 flex justify-start self-center items-center"> <i class="fas fa-waveform-path"></i>
                  <span>Sound</span> </span>
                <div class="flex items-center justify-end  self-center flex-1 ">
                  <label 
                    for="toogleA"
                    class="flex items-center cursor-pointer"
                  >
                  <div
                      class="mr-3 text-white font-medium"
                    >
                      OFF
                    </div>
                    <div class="relative">
                      <input id="toogleA" type="checkbox" class="hidden" />
                      <div
                        class="toggle__line w-10 h-4 bg-gray-400 rounded-full shadow-inner"
                      ></div>
                      <div
                        class="toggle__dot absolute w-6 h-6 bg-white rounded-full shadow inset-y-0 left-0"
                      ></div>
                    </div>
                    <div
                      class="ml-3 text-white font-medium"
                    >
                      ON
                    </div>
                  </label>
                  
                </div>
              </div>
          </li>
        </ul>
      </li>
      <li class="dropdown btn-profile hidden md:block">
        <a href="#" title="Account" class=" my--subaccount" >
          <span>
            <span class=" flex flex-col justify-center items-center self-center">
              <i class="fad fa-user-circle"></i>
              <span>Profile</span>
            </span>
          </span>
        </a>
      </li>
      @if(Route::currentRouteNamed( 'getExchange'))
      <li class="dropdown btn-new hidden md:block" id="history-trads" data-menu="history-menu">
        
        <a href="#" title="Account" class="dropdown-toggle my--subaccount" >
          <span>
            <span class="flex flex-col justify-center items-center self-center history">
              <i class="fad fa-history"></i>
              <span>History</span>
            </span>
          </span>
        </a>
        <ul class="dropdown-menu " id="history-menu" role="menu">
          <header>
            <ul class="nav nav-tabs nav-justified flex">
              <li class="active flex-1">
                <a href="#open-h" data-toggle="tab" class="text-white flex justify-center type history" style="width:100%;justify-content: center;">Open</a>
              </li>
              <li class=" flex-1">
                <a href="#close-h" data-toggle="tab" class="text-white flex justify-center type history" style="width:100%;justify-content: center;">Close</a>
              </li>

            </ul>
          </header>
          <div class="body tab-content">
            <div id="open-h" class="tab-pane active clearfix">
                <ul >
                  <li role="presentation" class="account-picture history-trades">
                    <div class=" cursor-pointer grid grid-cols-5 px-3" >
                      <div class="col-span-3 flex flex-col flex-1">
                  
                        <span class="balance-value">Amount: $10</span>
                        <span class="balance-value">Profit: $10</span>
                        <span class="balance-name">Time:12-10-2020 17:30:30</span>
                      </div>
                      <div class="col-span-2 flex flex-col justify-center self-center items-center">
                        <img src="exchange/img/bitcoin.webp" alt="">
                        <span class=" white balance-name text-center">BTCUSDT (demo) </span>
                      </div>
                    </div>
                  </li>
                  <li role="presentation" class="account-picture history-trades">
                    <div class=" cursor-pointer grid grid-cols-5 px-3" >
                      <div class="col-span-3 flex flex-col flex-1">
                  
                        <span class="balance-value">Amount: $10</span>
                        <span class="balance-value">Profit: $10</span>
                        <span class="balance-name">Time:12-10-2020 17:30:30</span>
                      </div>
                      <div class="col-span-2 flex flex-col justify-center self-center items-center">
                        <img src="exchange/img/bitcoin.webp" alt="">
                        <span class=" white balance-name text-center">BTCUSDT (demo) </span>
                      </div>
                    </div>
                  </li>
                </ul>
            </div>
            <div id="close-h" class="tab-pane  clearfix">
                <ul >
                  <li role="presentation" class="account-picture history-trades">
                    <div class=" cursor-pointer grid grid-cols-5 px-3" >
                      <div class="col-span-3 flex flex-col flex-1">
                  
                        <span class="balance-value">Amount: $1</span>
                        <span class="balance-value">Profit: $10</span>
                        <span class="balance-name">Time:12-10-2020 17:30:30</span>
                      </div>
                      <div class="col-span-2 flex flex-col justify-center self-center items-center">
                        <img src="exchange/img/bitcoin.webp" alt="">
                        <span class=" white balance-name text-center">BTCUSDT (demo) </span>
                      </div>
                    </div>
                  </li>
                  <li role="presentation" class="account-picture history-trades">
                    <div class=" cursor-pointer grid grid-cols-5 px-3" >
                      <div class="col-span-3 flex flex-col flex-1">
                  
                        <span class="balance-value">Amount: $10</span>
                        <span class="balance-value">Profit: $10</span>
                        <span class="balance-name">Time:12-10-2020 17:30:30</span>
                      </div>
                      <div class="col-span-2 flex flex-col justify-center self-center items-center">
                        <img src="exchange/img/bitcoin.webp" alt="">
                        <span class=" white balance-name text-center">BTCUSDT (demo) </span>
                      </div>
                    </div>
                  </li>
                </ul>
            </div>
          </div>
        </ul>
      </li>
      @endif
      <li class="visible-1200">
        <a href="#" class="btn-navbar" data-toggle="collapse" data-target=".sidebar" title="">
          <i class="fa fa-bars"></i>
        </a>
      </li>
 
    </ul>
  </div>
</header>