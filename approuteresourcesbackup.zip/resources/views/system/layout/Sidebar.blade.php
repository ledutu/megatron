<!-- check user -->
@if(1==1)
<nav id="sidebar" class="sidebar nav-collapse collapse " >
@else
<nav id="sidebar" class="sidebar nav-collapse collapse top-70" >
@endif

	<img class="img-logo-mobile  lg-hidden" src="exchange/img/logo_mobile.png">	
  <ul id="side-nav" class="side-nav">
	<li class="{{ (Route::currentRouteNamed( 'getExchange')) ? 'active' : '' }}">
		<a href="{{route('getExchange')}}"><i class="fad fa-chart-line"></i> <span class="name">Exchange</span></a>
	</li>
	<li class="{{ (Route::currentRouteNamed( 'getAgency')) ? 'active' : '' }}">
		<a href="{{route('getAgency')}}"><i class="fad fa-medal"></i> <span class="name">Agency</span></a></li>
	</li>
	<li>
		<a>
			<span class="line"></span>
	  </a>
	</li>
	<li class="{{ (Route::currentRouteNamed( 'getWallet')) ? 'active' : '' }}">
		<a href="{{route('getWallet')}}"><i class="fad fa-wallet"></i><span class="name">Wallet</span></a></li>
	</li>
	<li class="{{ (Route::currentRouteNamed( 'getDashboard')) ? 'active' : '' }}">
		<a href="{{route('getDashboard')}}"><i class="fal fa-sliders-h-square"></i><span class="name">Dashboard</span></a></li>
	</li>
	<li>
		<a>
			<span class="line"></span>
	  </a>
	</li>
	<li class="{{ (Route::currentRouteNamed( 'admin.getMember')) ? 'active' : '' }}">
		<a href="{{route('admin.getMember')}}"><i class="fad fa-users"></i><span class="name text-center">Manager User</span></a></li>
	</li>
	<li class="{{ (Route::currentRouteNamed( 'admin.getWallet')) ? 'active' : '' }}">
		<a href="{{route('admin.getWallet')}}"><i class="fad fa-wallet"></i><span class="name text-center">Manager Wallet</span></a></li>
	</li>
	<li class="{{ (Route::currentRouteNamed( 'admin.getTrade')) ? 'active' : '' }}">
		<a href="{{route('admin.getTrade')}}"><i class="fal fa-sliders-h-square"></i><span class="name text-center">Manager Trade</span></a></li>
	</li>
	<li class="{{ (Route::currentRouteNamed( 'admin.getKYC')) ? 'active' : '' }}">
		<a href="{{route('admin.getKYC')}}"><i class="fal fa-sliders-h-square"></i><span class="name text-center">Manager KYC</span></a></li>
	</li>
	<li class=" logout">
		<a>
			<span class="line"></span>
	  </a>
	  <a href="{{route('getLogout')}}"><i><img src="exchange/img/icon/lg.png" alt=""></i></i><span class="name">Logout</span></a>
	</li>
  </ul>
</nav>