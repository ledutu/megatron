@extends('system.layout.Master')
@section('css')
<style>
  .card-dashboard-static {
    min-height: 250px;
    background: rgb(35 31 32 / 0.6);
    margin: 0 2px;
    border: 1px solid #FFF200;
    width: 100%;
    margin: auto;
    border-radius: 15px;
  }

  .card-dashboard-mini {
    height: 150px;
    background: rgb(35 31 32 / 0.6);
    margin: 0 2px;
    border: 1px solid #FFF200;
    width: 100%;
    border-radius: 15px;
  }

  .card-table-static {
    height: 200px;
    background: rgb(35 31 32 / 0.6);
    margin: 0 2px;
    border: 1px solid #FFF200;
    width: 100%;
    margin: auto;
    border-radius: 2px;
  }

  #winlose {
    height: 150px;
    width: 150px;
    margin: auto;
  }

  .mb-5 {
    margin-bottom: 2.25rem;
  }

  .mt-5 {
    margin-top: 2.25rem;
  }

  .summary .title,
  .card-dashboard-static div .title {
    font-size: 17px;
    font-weight: 600;
    text-align: center;
    margin: auto;
    display: flex;
    justify-content: center;
    flex-direction: column;
  }

  .card-dashboard-mini div .title {
    font-size: 17px;
    font-weight: 600;
    text-align: left;
    display: flex;
    justify-content: flex-start;

  }

  .detail .span-circle {
    height: 20px;
    width: 20px;
    border: 5px solid;
    border-radius: 50%;
    margin-right: 5px;
  }

  .detail-tatic .detail:nth-child(1) .span-circle {
    border-color: #00b04f;
  }

  .detail-tatic .detail:nth-child(2) .span-circle {
    border-color: #ff0000;
  }

  .detail-tatic .detail:nth-child(3) .span-circle {
    border-color: #ffbf00;
  }

  .detail {
    display: flex;
    justify-content: flex-start;
    align-items: center;
    align-self: center;
    margin: 10px 0px;
  }

  .detail .span-text {
    font-size: 15px;
    font-weight: 700;

  }

  .summary .progress_summary {
    margin-top: 15px;
    width: 100%;
    height: 40px;
    position: relative;
  }

  .summary .progress_summary::after {
    position: absolute;
    top: 0;
    left: 0;
    content: "";
    height: 10px;
    width: 100%;
    border: 1px solid #FFF200;
    border-radius: 5px;
  }

  .summary .progress_summary::before {
    position: absolute;
    top: 0;
    left: 0;
    content: "";
    height: 10px;
    width: 50%;
    background: linear-gradient(90deg, #F4EB25, #F4C41B) !important;
    border: 1px solid #FFF200;
    border-radius: 5px;
  }

  .summary .progress_summary .up {
    position: absolute;
    bottom: 0;
    left: 0;
  }

  .summary .progress_summary .down {
    position: absolute;
    bottom: 0;
    right: 0;
  }

  .summary .progress_summary .down span,
  .summary .progress_summary .up span {
    font-size: 19px;
    font-weight: 800;
  }

  .summary .progress_summary .down span.percent {
    color: #ff0000;

  }

  .summary .progress_summary .up span.percent {
    color: #00b04f;
  }
  .header-tran{
    justify-content: space-between;
    align-self: center;
    align-items: center;
    align-content: center;
    justify-items: center;
    justify-self: center;
  }
  .btn-search{
    background: linear-gradient(90deg, #F4EB25, #F4C41B) !important;
    color: black;
    font-size: larger;
    font-weight: 700;
    width: max-content;
    display: flex;
    justify-content: center;
    align-items: center;
    align-content: center;
    align-self: center;

  }
  .pick-date{
    border-top: none;
    border-left: none;
    background: #eeeeee1f;
    margin-right: 5px;
    font-size: 12px;
    font-weight: 700;
    color: white;
  }
</style>

@endsection
@section('content')
<div class="grid grid-cols-2 gap-8 gap-y-20">
  <div class="col-span-2 grid grid-cols-12">
    <div class="col-span-12 xl:col-span-1"></div>
    <div class="grid grid-cols-2 gap-8 col-span-12 xl:col-span-10">
      <div class="col-span-2 lg:col-span-1">
        <div class="card-dashboard-static grid grid-cols-2 gap-0">
          <div class="col-span-2 grid grid-cols-2 gap-4">
            <div class="col-span-2 lg:col-span-1">
              <div id="winlose" class="mb-5"></div>
            </div>
            <div class="col-span-2 lg:col-span-1 detail-tatic self-center items-center">
              <div class="detail">
                <div class="span-circle"></div>
                <div class="span-text">Total Trade Win</div>
              </div>
              <div class="detail">
                <div class="span-circle"></div>
                <div class="span-text">Total Trade Loser</div>
              </div>
              <div class="detail">
                <div class="span-circle"></div>
                <div class="span-text">Total Trade Draw</div>
              </div>
            </div>


          </div>
          <div class="col-span-2 grid grid-cols-2 gap-4">
            <div class="col-span-2 lg:col-span-1 border-r-2">
              <span class="title">
                <span>Win Rate</span>
                <span> 0%</span>
              </span>
            </div>
            <div class="col-span-2 lg:col-span-1">
              <span class="title">
                <span>Total Trade</span>
                <span> 0</span>
              </span>
            </div>
          </div>

        </div>
      </div>
      <div class="col-span-2 lg:col-span-1 grid grid-cols-2 gap-4">
        <div class="col-span-2 lg:col-span-1">
          <div class="card-dashboard-mini grid grid-cols-3">
            <div class="col-span-1 flex flex-col self-center items-center">
              <img src="exchange/img/icon/das-1.png" alt="" srcset="">
            </div>
            <div class="col-span-2 flex flex-col self-center ">
              <span class="title">Net Profit</span>
              <span class="title">$ 0</span>
            </div>
          </div>
        </div>
        <div class="col-span-2 lg:col-span-1">
          <div class="card-dashboard-mini grid grid-cols-3">
            <div class="col-span-1 flex flex-col self-center items-center">
              <img src="exchange/img/icon/das-2.png" alt="" srcset="">
            </div>
            <div class="col-span-2 flex flex-col  self-center">
              <span class="title">Total Income</span>
              <span class="title">$ 0</span>
            </div>
          </div>
        </div>
        <div class="col-span-2 summary">
          <div class="title">Transaction Summary</div>
          <div class="progress_summary">
            <div class="up">
              <span class="text">UP</span>
              <span class="percent">0.00%</span>
            </div>
            <div class="down">
              <span class="text">Down</span>
              <span class="percent">0.00%</span>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>
  <div class="col-span-2 grid grid-cols-12">
    <div class="col-span-12 xl:col-span-1"></div>
    <div class="col-span-12 xl:col-span-10 grid grid-cols-1">
      <div class="col-span-1 ">
        <div class="flex header-tran">
          <div class="float-left ">
            <h2 >History Transaction</h2>
          </div>
        
          <div class="seach-date float-right ">
            <form action="" method="get" class="flex self-center items-center">
              @csrf
              <input id="flatpickr" class="form-control text-white pick-date" name="from" placeholder="Select Date From">
              <input id="flatpickr-2" class="form-control text-white pick-date" name="to" placeholder="Select Date To">
              <button class="btn-search btn button">Search</button>
            </form>
     
          </div>
        </div>
      </div>
      <div class="col-span-1">
        <div class="card-table-static reponsive">
          <table id="transaction" class="display reponsive datatable" style="width:100%">
            <thead>
              <tr>
                <th>Name</th>
                <th>Position</th>
                <th>Office</th>
                <th>Age</th>
                <th>Start date</th>
                <th>Salary</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Michael Bruce</td>
                <td>Javascript Developer</td>
                <td>Singapore</td>
                <td>29</td>
                <td>2011/06/27</td>
                <td>$183,000</td>
              </tr>
              <tr>
                <td>Donna Snider</td>
                <td>Customer Support</td>
                <td>New York</td>
                <td>27</td>
                <td>2011/01/25</td>
                <td>$112,000</td>
              </tr>
            </tbody>

          </table>
        </div>
      </div>

    </div>
  </div>
</div>

@endsection
@section('scripts')

<script type="text/javascript">
var example = flatpickr('#flatpickr');
var example_2 = flatpickr('#flatpickr-2');
  $(document).ready(function () {
    $('#transaction').DataTable({
      "bPaginate": true,
      "bLengthChange": false,
      "bFilter": true,
      "searching": false,
      "bInfo": false,
      "bAutoWidth": false
    });

  });



  var colorPalette = ['#00b04f', '#ff0000', '#ffbf00'];
  var defaul_null = ['#ffbf00'];
  var data_value = [{ value: 335, name: 'Win' },
  { value: 310, name: 'Loser' },
  { value: 234, name: 'Draw' },]
  var data_null = [{ value: 0, name: 'Win ' },]
  var option = {
    tooltip: {
      trigger: 'item',
      formatter: '{a} <br/>{b}: {c} ({d}%)'
    },
    series: [
      {
        name: 'Trade Stat',
        type: 'pie',
        color: colorPalette,
        radius: ['60%', '80%'],
        avoidLabelOverlap: false,
        label: {
          show: false,
          position: 'center'
        },
        emphasis: {
          label: {
            show: true,
            fontSize: '15',
            fontWeight: 'bold'
          }
        },
        labelLine: {
          show: false
        },
        data: data_null
      },

    ]
  };
  var winlose_container = document.getElementById('winlose');
  var winlose = echarts.init(winlose_container);
  winlose.setOption(option);

  window.onresize = function () {
    winlose.resize();
  }
</script>
@endsection