@extends('system.layout.Master')
@section('css')
<style>

</style>

@endsection
@section('content')
<div class="grid grid-cols-12 gap-4">
  <div class="xl:col-span-10 lg:col-span-9 xs:col-span-12 md:col-span-12 col-span-12 p-0 m-0 ">
    <section class="widget widget-chart p-0">
      <div id="chart-panel">
        <div class="sell-div  ">
          <p class="animate__bounceIn">SELL</p>
          <span class="animate__bounceIn"></span>
        </div>
        <div class="buy-div  ">
          <p class="animate__bounceIn">BUY</p>
          <span class="animate__bounceIn"></span>
        </div>
        <div class="profit-div  ">
          <p class="animate__bounceIn">PROFIT</p>
          <span class="animate__bounceIn"></span>
        </div>
        <div id="MainCharts" style="height:100%;width: 100%;"></div>
      </div>
    </section>
    <section
      class="widget widget-tabs xl:col-span-12 lg:col-span-12 md:col-span-12  sm:col-span-12 col-span-12 row-start-1 xl:row-start-1	">
      <header>
        <ul class="nav nav-tabs nav-justified tab-de">
          <li class="active flex-1">
            <a href="#Indicators" data-toggle="tab" class="text-white">Indicators</a>
          </li>
          <li class=" flex-1">
            <a href="#Results" data-toggle="tab" class="text-white">Last Results</a>
          </li>

        </ul>
      </header>
      <div class="body tab-content">
        <div id="Indicators" class="tab-pane active clearfix">
          <div class=" grid grid-cols-12 self-center justify-center items-center bg-transparent">
            <div class="col-span-4 relative">
              <div class="title-gua">
                Oscillators
              </div>
              <div class="min-gua " id="gua_1"></div>
              <div class="label-detail flex justify-center self-center gua-detail-div qua_1">
                <span span class="text-sell">
                  <span>Sell</span>  
                  <span class="value-sell"> 0</span> 
                </span>
              
                <span class="text-buy">
                  <span>Buy</span> 
                  <span class="value-buy"> 0</span>
                </span>
              </div>
            </div>
            <div class="col-span-4 relative">
              <div class="title-gua">
                Summary
              </div>
              <div class="min-gua " id="gua_2"></div>
              <div class="label-detail flex justify-center self-center gua-detail-div qua_2">
                <span span class="text-sell">
                  <span>Sell</span>  
                  <span class="value-sell"> 0</span> 
                </span>
                
                <span class="text-buy">
                  <span>Buy</span> 
                  <span class="value-buy"> 0</span>
                </span>
              </div>
            </div>
            <div class="col-span-4 relative">
              <div class="title-gua">
                Moving Averages
              </div>
              <div class="min-gua " id="gua_3"></div>
              <div class="label-detail flex justify-center self-center gua-detail-div qua_3">
                <span span class="text-sell">
                  <span>Sell</span>  
                  <span class="value-sell"> 0</span> 
                </span>
                
                <span class="text-buy">
                  <span>Buy</span> 
                  <span class="value-buy"> 0</span>
                </span>
              </div>
            </div>
          </div>
        </div>
        <div id="Results" class="tab-pane">
          <div class=" grid grid-cols-12">
            <div class="xl:col-span-3 col-span-12"></div>
            <div
              class=" water-circle xl:col-span-6 col-span-12 grid grid-cols-12 lg:my-10 col-span-1 lg:mb-5 gap-4 justify-center"
              id="Statistical">
              <div class="col-span-1 grid grid-cols-1 gap-2">
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
              </div>
              <div class="col-span-1 grid grid-cols-1 gap-2">
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
              </div>
              <div class="col-span-1 grid grid-cols-1 gap-2">
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
              </div>
              <div class="col-span-1 grid grid-cols-1 gap-2">
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
              </div>
              <div class="col-span-1 grid grid-cols-1 gap-2">
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
              </div>
              <div class="col-span-1 grid grid-cols-1 gap-2">
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
              </div>
              <div class="col-span-1 grid grid-cols-1 gap-2">
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
              </div>
              <div class="col-span-1 grid grid-cols-1 gap-2">
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
              </div>
              <div class="col-span-1 grid grid-cols-1 gap-2">
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
              </div>
              <div class="col-span-1 grid grid-cols-1 gap-2">
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
              </div>
              <div class="col-span-1 grid grid-cols-1 gap-2">
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
              </div>
              <div class="col-span-1 grid grid-cols-1 gap-2">
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
                <span class="col-span-1"></span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <div class="xl:col-span-2 lg:col-span-3  xs:col-span-12 md:col-span-12  col-span-12 ">
    <div class="right-global flex  flex-col gap-4 widget-left px-3">
      <div class="col-span-12 mt-5 lg:block flex">
        <label for="" class="hidden lg:block">Amount:</label>
        <button class="btn btn-updown hidden-lg" onclick="selectAmount(-5)"><i class="fas fa-minus"></i></button>
        <input id="amount" type="number" class="form-control amount-input flex-1" step="5" name="amount" />
        <button class="btn btn-updown hidden-lg" onclick="selectAmount(5)"><i class="fas fa-plus"></i> </button>
      </div>
      <div class=" col-span-12  pl-2 pr-2 hidden lg:block">
        <div class="price-button">
          <button class="button-price" onclick="selectAmount(5)">+5</button>
          <button class="button-price" onclick="selectAmount(10)">+10</button>
          <button class="button-price" onclick="selectAmount(20)">+20</button>
          <button class="button-price" onclick="selectAmount(50)">+50</button>
          <button class="button-price last" onclick="selectAmount(100)">+100</button>
          <button class="button-price last" onclick="selectAmount('all')">All</button>
        </div>

      </div>
      <div class="col-span-12 grid col-span-1 profit-show">
        <label for="">Profit</label>
        <span class="profit-1">95% <span class="profit-2" id="amount_2">+$0</span></span>
      </div>
      <div class="col-span-12  col-span-1 hidden lg:grid">
        <label for="">Traders sentiments</label>
        <div class="flex relative mb-10">

          <span class="buy-progress"></span>
          <span class="sell-progress"></span>
          <span class="buy-percen">55%</span>
          <span class="sell-percen">45%</span>
        </div>
      </div>
      <div class="col-span-12 ">
        <div class="buysell-button">
          <div class="btn-group">
            <button class=" btn button-buysell btn-buy bet" type="button" data-type="buy">
              <span>BUY</span>
            </button>
            <div class="count-down">
              <span>
                <small class="font-1 timeText"></small>
                <p class="main-count m-0">
                  00</p>
              </span>
            </div>
            <button class="btn button-buysell btn-sell bet" type="button" data-type="sell">
              <span>SEll</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection
@section('scripts')
<script src="exchange/js/index.js"></script>

<script src="exchange/js/colyseus.js"></script>
<script>
  var base_url = 'https://beta.igtrade.co';
  var host = window.document.location.host.replace(/:.*/, '');
  var client = new Colyseus.Client('wss://socket.igtrade.co/');
  var user = { subID: {{ $subID }}, token: '{{$token}}', currency: {{$currency}} };
  var statistical = {!! json_encode($historyGame)!!};
  @if (count($betArray))
    var _betList = {!! json_encode($betArray)!!};
  @else
  var _betList = {};
  @endif
  $(document).ready(function () {
    _coin = window.location.search;
    if (_coin == '?coin=gold') {
      $('.img_coin').html('<img src="exchange/img/gold.png">');
    } else {
      $('.img_coin').html('<img src="exchange/img/eusd.png">');
    }
  });
  $('.select_coin').click(function () {
    var _name = $(this).data('name');
    window.location.search = 'coin=' + _name + '';
  });
</script>


<script src="exchange/js/convertEchart.js?v=<?=time()?>"></script>
<script src="exchange/js/echarts-config.js?v=<?=time()?>"></script>
<script src="exchange/js/newchart.js?v=<?=time()?>"></script>
@endsection