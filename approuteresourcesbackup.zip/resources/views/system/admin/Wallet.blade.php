@extends('system.layout.Master')
@section('css')
<style>
  .card-dashboard-mini {

    background: rgb(35 31 32 / 0.6);
    margin: 0 2px;
    border: 1px solid #FFF200;
    width: 100%;
    border-radius: 15px;
    padding: 10px;
  }

  .card-table-static {
    min-height: 200px;
    background: rgb(35 31 32 / 0.6);
    margin: 0 2px;
    border: 1px solid #FFF200;
    width: 100%;
    margin: auto;
    border-radius: 2px;
  }

  .mt-5e {
    margin-top: 5em;
  }

  .btn-search {
    background: linear-gradient(90deg, #F4EB25, #F4C41B) !important;
    color: black;
    font-size: larger;
    font-weight: 700;
    width: 150px;
    display: flex;
    justify-content: center;
    align-items: center;
    align-content: center;
    align-self: center;
    height:35px;
    margin-left:5px;
    margin-right:5px;
  }

  .btn-cancel {
    background: linear-gradient(90deg, #ed3935, #db4224) !important;
    color: #fff;
    font-size: larger;
    font-weight: 700;
    width: 150px;
    display: flex;
    justify-content: center;
    align-items: center;
    align-content: center;
    align-self: center;
    height:35px;
    margin-left:5px;
    margin-right:5px;
  }

  .btn-export {
    background: linear-gradient(90deg, #63ae61, #7cb772) !important;
    color: #fff;
    font-size: larger;
    font-weight: 700;
    width: 150px;
    display: flex;
    justify-content: center;
    align-items: center;
    align-content: center;
    align-self: center;
    height:35px;
    margin-left:5px;
    margin-right:5px;
  }

  .form-group {
    margin-bottom: 0;
  }
  .form-group .form-control{
    height: 35px;
    background: transparent;
    border-radius: 15px;
    color: white;
    font-size: 15px;
    font-weight: 600;
  }
  .form-group label{
    font-size: 15px;
    font-weight: 600;
    padding-left: 10px;
  }
  .my-2{
    margin-top: 0.5rem;
    margin-bottom: 0.5rem;
  }
</style>
@endsection
@section('content')
<div class="grid grid-cols-8 gap-8 gap-y-20">
<div class="col-span-8 lg:col-span-1"></div>
  <div class="col-span-8 lg:col-span-2">
    <div class="card-dashboard-mini ">
      <form action="" method="post" class="grid grid-cols-1 gap-8">
        @csrf
        <div class="form-group  flex flex-col ">
          <label for="">User ID</label>
          <input type="text" require name="User_ID" class="form-control" placeholder="Enter User ID">
        </div>
        <div class="form-group  flex flex-col ">
          <label for="">Amount</label>
          <input type="number" require step="0.001" name="User_Amount" class="form-control" placeholder="Enter Amount Spend">
        </div>
        <div class="form-group  flex flex-col ">
          <label for="">Currency</label>
          <select name="User_Currency" class="form-control" >
            <option class="text-black"value="">--Select--</option>
            <option class="text-black"value="5">USDT</option>
            <option class="text-black"value="1">BTC</option>
            <option class="text-black"value="2">ETH</option>
          </select>
        </div>
        <div class="form-group  flex flex-col ">
          <label for="">Transaction Hash (Optional)</label>
          <input type="text" name="User_Transaction" class="form-control" placeholder="Enter Transaction">
        </div>
        <div class="form-group ">
          <div div class="flex justify-center">
            <button class="btn button btn-search">Deposit</button>
          </div>
        </div>
      </form>
    </div>
  </div>
  <div class="col-span-8 lg:col-span-4">
    <div class="card-dashboard-mini">
      <form method="get" class="grid grid-cols-2 gap-8">
        @csrf
        <div class="form-group col-span-2 lg:col-span-1 flex flex-col ">
          <label for="">Wallet ID</label>
          <input type="text" name="User_Wallet" class="form-control" placeholder="Enter User ID">
        </div>
        <div class="form-group col-span-2 lg:col-span-1 flex flex-col ">
          <label for="">User ID</label>
          <input type="text" name="User_ID" class="form-control" placeholder="Enter User ID">
        </div>
        <div class="form-group col-span-2 lg:col-span-1 flex flex-col " >
          <label for="">User Email</label>
          <input type="text" name="User_Email" class="form-control" placeholder="Enter User Email">
        </div>
        <div class="form-group col-span-2 lg:col-span-1 flex flex-col ">
          <label for="">Date From</label>
          <input id="date-picker-3" class="form-control" name="Date_From" placeholder="Select Date From">
        </div>
        <div class="form-group col-span-2 lg:col-span-1 flex flex-col ">
          <label for="">Data To</label>
          <input id="date-picker-3" class="form-control" name="Date_To" placeholder="Select Date From">
        </div>
        <div class="form-group col-span-2 lg:col-span-1 flex flex-col ">
          <label for="">Tree</label>
          <input type="text" name="User_Tree" class="form-control" placeholder="Enter User Tree">
        </div>
        <div class="form-group col-span-2 lg:col-span-1 flex flex-col ">
          <label for="">Action</label>
          <select name="User_Status" class="form-control" >
            <option class="text-black"value="">--Select--</option>
            <option class="text-black"value="1">Active</option>
            <option class="text-black"value="0">Not Active</option>
          </select>
        </div>
        <div class="form-group col-span-2 lg:col-span-1 flex flex-col ">
          <label for="">User Level</label>
          <select name="User_Level" class="form-control" >
            <option class="text-black"value="">--Select--</option>
            <option class="text-black"value="0">Member</option>
            <option class="text-black"value="1">Admin</option>
            <option class="text-black"value="5">Bot</option>

          </select>
        </div>
        <div class="form-group col-span-2 flex flex-col ">
          <div class="flex justify-center ">
            <button class="btn button btn-search">Search</button>
            <button class="btn button btn-export">export</button>
            <button class="btn button btn-cancel">Reset</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
<div class="grid grid-cols-12 gap-8 mt-5e ">
  <div class="col-span-12 lg:col-span-1 flex flex-col "></div>
  <div class="col-span-12 lg:col-span-10">
    <div class="card-table-static reponsive">
      <table id="member-list" class="display reponsive datatable" style="width:100%">
        <thead>
            <tr>
                <th>Name</th>
                <th>Position</th>
                <th>Office</th>
                <th>Age</th>
                <th>Start date</th>
                <th>Salary</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Michael Bruce</td>
                <td>Javascript Developer</td>
                <td>Singapore</td>
                <td>29</td>
                <td>2011/06/27</td>
                <td>$183,000</td>
            </tr>
            <tr>
                <td>Donna Snider</td>
                <td>Customer Support</td>
                <td>New York</td>
                <td>27</td>
                <td>2011/01/25</td>
                <td>$112,000</td>
            </tr>
        </tbody>
       
      </table>
    </div>
  </div>
</div>
@endsection
@section('scripts')

<script  type="text/javascript">
  var ex = flatpickr('#date-picker-3');
  $(document).ready(function() {
    $('#member-list').DataTable({
      "bPaginate": true,
      "bLengthChange": false,
      "bFilter": true,
      "searching": false,
      "bInfo": false,
      "bAutoWidth": false 
    });
  });
</script>
@endsection