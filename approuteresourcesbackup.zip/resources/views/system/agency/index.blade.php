@extends('system.layout.Master')
@section('css')
<style>
  .card-dashboard-mini {
    min-height: 150px;
    background: rgb(35 31 32 / 0.6);
    margin: 0 2px;
    border: 1px solid #FFF200;
    width: 100%;
    border-radius: 15px;
    padding: 20px;

  }
  .bottom-agency {
    position: fixed;
    bottom: 0;
    right: 0;
    background: black;
    height: 90px;
    margin-left: 90px;
    left: 0;
  }
  .body-agency{
    height: calc(100vh - 300px );
    display: flex;
    justify-content: center;
    align-items: center;
}
.btn-buy{
    background: linear-gradient(90deg, #F4EB25, #F4C41B) !important;
    color: black;
    font-size: larger;
    font-weight: 700;
    width: 200px;
    display: flex;
    justify-content: center;
    align-items: center;
    align-content: center;
    align-self: center;
    margin-top: 10px;
    margin-bottom: 10px;
    height: 50px;
  }
  .text-about{
    font-size: 28px;
    font-weight: bold;
  }
  .register,
  .sponsor{
    position: relative;
    height: 40px;
    margin-bottom: 20px;
  }
  .btn-copy{
    height: 35px;
    width: 100px;
    background-color: #FFF200;
    color: black;
    border-radius: 10px;
    position: absolute;
    top: 0;
    right: 2px;
    bottom: 0;
    font-size: initial;
    font-weight: 700;
    margin: auto;

  }
  .input-copy{
    background: transparent!important;
    border: #F4EB25 1px solid;
    color: white;
    padding-left: 5px;
    position: absolute;
    height: 40px;
    border-radius: 10px;
    font-size: 15px;
    font-weight: 600;
    
  }
  .sponsor {
    width: 50%;
  }
  .card-dashboard-mini label
  {
    font-size: 17px;
    font-weight: 700;
  }
  .tour .title{
    font-size: 17px;
    font-weight: 700;
    color:white;
  }
  .tour .content-text{
    font-size: 15px;
    font-weight: 500;
    color:white;
  }
  .mr-2{
    margin-right: 0.5rem;
  }
  .card-dashboard-mini.link .title,
  .card-dashboard-mini.static .title{
    font-size: 17px;
    font-weight: 700;
    text-align: center;
  }
  .card-dashboard-mini.static .content-detail{
    font-size: 17px;
    font-weight: 700;
    text-align: center;
  }
  .card-dashboard-mini.static{
    display: flex;
    align-items: center;
    align-self: center;
    justify-content: center;
    flex-direction: column;
  }
  .mb-2{
    margin-bottom: 0.5rem;
  }
  .card-dashboard-mini.member{
    padding: 0;
    border-radius: 2px;
  }
</style>
@endsection
@section('content')
@if(1==2)
<div class="body-agency">
  <div class="grid grid-cols-12 flex-1 ">
    <div class="col-span-12 xl:col-span-1"></div>
    <div class="col-span-12 xl:col-span-10 grid grid-cols-12 gap-8 gap-y-10">
      <div class="col-span-12 lg:col-span-6 flex flex-col sefl-center items-center justify-center">
        <span class="text-about text-center">
          You need to buy Agency license to receive <br> agency commissions and trading commissions
        </span>
        <button class="btn-buy button btn">Buy Now $100</button>
      </div>
      <div class="col-span-12 lg:col-span-6 card-dashboard-mini">
     
        <label for="">Register Link</label>
        <div class=" register">
          <input type="text" id="linkref" class="form-control input-copy" readonly value="123">
          <button class="btn button btn-copy" onclick="Copy_link('linkref')">Copy</button>
        </div>
        <label for="">Sponsor Code</label>
        <div class="sponsor ">
          <input type="text" id="sponsorcode" class="form-control input-copy" readonly value="123">
          <button class="btn button btn-copy" onclick="Copy_link('sponsorcode')">Copy</button>
        </div>
        
      </div>
    </div>
  </div>
</div>
@endif
<div class="body-join grid grid-cols-1 gap-6 gap-y-20">
  <div class="grid grid-cols-10 gap-8">
    <div class="col-span-10 lg:col-span-2"></div>
    <div class="col-span-10 lg:col-span-2">
      <div class="card-dashboard-mini static">
        <div class="title mb-2">Total Commission</div>
        <div class="content-detail">5 USDT</div>
      </div>
    </div>
    <div class="col-span-10 lg:col-span-2">
      <div class="card-dashboard-mini static">
        <div class="title mb-2">Total Member Invited</div>
        <div class="content-detail">100 Member</div>
      </div>
    </div>
    <div class="col-span-10 lg:col-span-2">
      <div class="card-dashboard-mini link">
        <div class="title mb-2"> Invitation Link</div>
          <div class=" register">
            <input type="text" id="linkref" class="form-control input-copy" readonly value="123">
            <button class="btn button btn-copy" onclick="Copy_link('linkref')">Copy</button>
          </div>
      </div>
    </div>
  </div>
  <div class="grid grid-cols-12">
    <div class="col-span-12  xl:col-span-1">
      
    </div>
    <div class="col-span-12 xl:col-span-10">
      <div class="card-dashboard-mini member reponsive">
        <table id="member-list" class="display reponsive datatable" style="width:100%">
          <thead>
              <tr>
                  <th>Name</th>
                  <th>Position</th>
                  <th>Office</th>
                  <th>Age</th>
                  <th>Start date</th>
                  <th>Salary</th>
              </tr>
          </thead>
          <tbody>
              <tr>
                  <td>Michael Bruce</td>
                  <td>Javascript Developer</td>
                  <td>Singapore</td>
                  <td>29</td>
                  <td>2011/06/27</td>
                  <td>$183,000</td>
              </tr>
              <tr>
                  <td>Donna Snider</td>
                  <td>Customer Support</td>
                  <td>New York</td>
                  <td>27</td>
                  <td>2011/01/25</td>
                  <td>$112,000</td>
              </tr>
          </tbody>
         
        </table>
      </div>
    </div>
  </div>
</div>
<div class="bottom-agency grid grid-cols-12 gap-6">
  <div class="col-span-12 xl:col-span-2"></div>
  <div class="col-span-12 lg:col-span-4 xl:col-span-3 g flex self-center items-center">
    <img src="exchange/img/icon/agency.png" alt="" class="mr-2">
    <div class=" flex flex-col text-left tour">
      <span class="title">Invite Friends</span>
      <span class="content-text">Invite friends to register IG Trade through the link</span>
    </div>
  </div>
  <div class="col-span-12 lg:col-span-4 xl:col-span-3 flex self-center items-center">
    <img src="exchange/img/icon/agency.png" alt="" class="mr-2">
    <div class=" flex flex-col text-left tour">
      <span class="title">Friends sign-up</span>
      <span class="content-text">Friends accept the invitation, complete registration and play</span>
    </div>
  </div>
  <div class="col-span-12 lg:col-span-4 xl:col-span-3  flex self-center items-center">
    <img src="exchange/img/icon/agency.png" alt="" class="mr-2">
    <div class=" flex flex-col text-left tour">
      <span class="title">
        Get a corresponding proportion of commission</span>
      <span class="content-text">Easily get commission</span>
    </div>
  </div>
</div>
@endsection
@section('scripts')
<script>
   $(document).ready(function() {

    $('#member-list').DataTable({
      "bPaginate": true,
      "bLengthChange": false,
      "bFilter": true,
      "searching": false,
      "bInfo": false,
      "bAutoWidth": false 
    });
} );
</script>
@endsection