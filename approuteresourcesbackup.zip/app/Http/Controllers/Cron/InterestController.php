<?php

namespace App\Http\Controllers\Cron;

use App\Model\Money;
use App\Model\User;
use App\Model\Wallet;
use App\Model\Log;
use App\Model\Investment;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Mail;
use DB;

use App\Jobs\SendTelegramJobs;
use App\Jobs\CommissionResonanceJobs;
class InterestController extends Controller
{
	public static function getPaySalesSystem($investment){
		$todayThisMonth = (int)date('j');
		if($todayThisMonth != '05'){
			// dd('today is '.$todayThisMonth);
		}
		$arrPercent = [1=>0.015, 2=>0.02, 3=>0.03];
		$arrNameLevel = [1=>'IB', 2=>'MIB', 3=>'FIB'];
		$currency = 13;
		$rateCurrency = app('App\Http\Controllers\System\CoinbaseController')->coinRateBuy('USDT');
		$action = 13;
		foreach($investment as $invest){
			$arrParent = explode(',', $invest->User_Tree);
			$arrParent = array_reverse($arrParent);
			$percentCheck = 0;
			$amount = $invest->investment_Amount;
			for($i = 1; $i<=3; $i++){
				if(!isset($arrParent[$i])){
					break;
				}
				$parentTree = User::find($arrParent[$i]);
				if(!$parentTree){
					Log::insertLogProfit($parentTree->User_ID,'Commission Sales', 'User ID: '.$parentTree->User_ID.' Not Found');
					continue;
				}
				$getInvestUser = Investment::where('investment_User', $parentTree->User_ID)->where('investment_Time', '<=', $invest->investment_Time)->where('investment_Status', '<>', -1)->orderBy('investment_ID')->first();
				if(!$getInvestUser){
					continue;
				}
				if($parentTree->User_Agency_Level < 1){
					Log::insertLogProfit($parentTree->User_ID,'Commission Sales', 'User ID: '.$parentTree->User_ID.' Not Enough Level');
					continue;
				}
				$percent = $arrPercent[$parentTree->User_Agency_Level] - $percentCheck;
				if($percent <= 0){
					Log::insertLogProfit($parentTree->User_ID,'Commission Sales', 'User ID: '.$parentTree->User_ID.' Same Level');
					continue;
				}
				$percentCheck = $arrPercent[$parentTree->User_Agency_Level];

				$amountCom = $amount*$percent;
				$money = new Money();
				$money->Money_User = $parentTree->User_ID;
				$money->Money_USDT = $amountCom;
				$money->Money_Time = time();
				$money->Money_Comment = 'Sales Commission '.$arrNameLevel[$parentTree->User_Agency_Level].' From F'.$i.' User ID: '.$invest->User_ID.' ('.($percent*100).'%)';
				$money->Money_Currency = $currency;
				$money->Money_MoneyAction = $action;
				$money->Money_Address = '';
				$money->Money_Rate = $rateCurrency;
				$money->Money_MoneyStatus = 1;
				$money->save();
				//Update Balance
				$updateBalance = User::updateBalance($parentTree->User_ID, $currency, $amountCom);
			}
		}
        
	    return true;
	}
	public static function getAmountLotTotal($investment, $amountLot){
		// $userPackage[1] = $investment->where('investment_Amount', '>=', 99)->where('investment_Amount', '<', 1000)->count();
		// $userPackage[2] = $investment->where('investment_Amount', '>=', 1000)->where('investment_Amount', '<', 5000)->count();
		// $userPackage[3] = $investment->where('investment_Amount', '>=', 5000)->where('investment_Amount', '<', 20000)->count();
		// $userPackage[4] = $investment->where('investment_Amount', '>=', 20000)->where('investment_Amount', '<', 100000)->count();
		// $userPackage[5] = $investment->where('investment_Amount', '>=', 100000)->count();
		$today = date('Y-m-d');
		$userPackage = DB::table('lot')->where('lot_Date', $today)
										->pluck('lot_Member', 'lot_Package')->toArray();
		// dd($userPackage);
		$arrInfoLot = [
						1=>['min'=>99, 'max'=>1000, 'percent'=>0.1], 
						2=>['min'=>1000, 'max'=>5000, 'percent'=>0.15], 
						3=>['min'=>5000, 'max'=>20000, 'percent'=>0.2], 
						4=>['min'=>20000, 'max'=>100000, 'percent'=>0.25], 
						5=>['min'=>100000, 'max'=>9999999, 'percent'=>0.3]];
		$amountPerLot = 16;
		$arrAmountLot = [];
		foreach($userPackage as $p=>$package){
			$amountComLot = $amountPerLot * $amountLot * $arrInfoLot[$p]['percent'] / ($package == 0 ? 1 : $package);
			$arrAmountLot[$p] = ['min'=>$arrInfoLot[$p]['min'], 'max'=>$arrInfoLot[$p]['max'], 'amount'=>$amountComLot];
		}
		// dd($userPackage, $arrAmountLot);
		return $arrAmountLot;
	}
	public static function getAmountLotUser($arrAmount, $amountInvest){
		$amount = 0;
		foreach($arrAmount as $a){
			if($amountInvest >= $a['min'] && $amountInvest < $a['max']){
				return $a['amount'];
			}
		}
		return $amount;
	}
	public static function getProfitsLot($investment, $amountLot){
		// dd($investment, 321);
	    if(!count($investment)){
		    Log::insertLogProfit('', 'Profit LOT', 'Collect Is Null');
		    return false;
		}
		$now = strtotime(date('Y-m-d H:i:s'));
		$rate = app('App\Http\Controllers\System\CoinbaseController')->coinRateBuy();
		$RateCoin[5] = $rate['USDT'];
		$arrAmount = self::getAmountLotTotal($investment, $amountLot);
		// dd($arrAmount, 123);
		$coin = 5;
		$rate = $RateCoin[$coin];
		$action = 10;
		foreach($investment as $i){
			// kiểm tra đã trả lãi hay chưa
			$checkProfits = Money::where('Money_MoneyStatus', '<>', -1)
								->where('Money_MoneyAction', $action)
								->where('Money_Time', '>=', strtotime('today'))
								->where('Money_User', $i->investment_User)
								// ->where('Money_Investment', $i->investment_ID)
								->orderByDesc('Money_Time')
								->first();
			if($checkProfits){
			    // Log::insertLogProfit($i->investment_User, 'Profit LOT', 'Investment User:'.$i->investment_User.' Paid!');
				// continue;
			}
			$amountComLot = self::getAmountLotUser($arrAmount, $i->investment_Amount);
			if($amountComLot <= 0){
				Log::insertLogProfit($i->investment_User, 'Profit LOT', 'Investment User:'.$i->investment_User.' Amount LOT $'.$amountComLot.'!');
				continue;
			}
			// echo $i->investment_User.": $amountComLot - Daily ".($amountLot)." LOT From Investment $".number_format($i->investment_Amount,2)." <br>";
			// continue;
			$row = new Money();
			$row->Money_User = $i->investment_User;
			$row->Money_USDT = $amountComLot;
			$row->Money_Time = $now;
			$row->Money_Comment = "Daily $amountLot LOT From Investment $".number_format($i->investment_Amount,2);
			$row->Money_MoneyAction = $action;
			$row->Money_MoneyStatus = 1;
			$row->Money_Currency = $coin;
			$row->Money_Investment = $i->investment_ID;
			$row->Money_Rate = $rate;
			$row->save();
			//Update Balance
			$updateBalance = User::updateBalance($i->investment_User, $coin, $amountComLot);
		}
	}
	public static function getPercentProfit($arrPercent, $invest){
		$dateInvest = date('Y-m-d', $invest->investment_Time);
		$amount = $invest->investment_Amount;
		$percent = 0;
		foreach($arrPercent as $p){
			// dd($dateInvest < $p->Percent_Time, $p);
			if(($amount >= $p->package_Min) && $amount <= $p->package_Max /*&& $dateInvest < $p->Percent_Time*/){
				return $p->Percent_Percent;
				// $percent += $p->Percent_Percent;
			}
		}
		return $percent;
	}
	public static function getProfits($investment){
	    if(!count($investment)){
		    Log::insertLogProfit('', 'Profit', 'Collect Is Null');
		    return false;
	    }
		$now = strtotime(date('Y-m-d 02:00:00'));
		$dateThisMonth = (int)date('t');
		$rate = app('App\Http\Controllers\System\CoinbaseController')->coinRateBuy();
		$RateCoin[5] = $rate['USDT'];
		// $mondayThisWeek = date('Y-m-d', strtotime('monday this week'));
		// $thursdayThisWeek = date('Y-m-d', strtotime('friday this week'));
		$today = date('Y-m-d');
		$arrPercent = DB::table('profit')->leftJoin('package', 'package_ID', 'Percent_PackageID')
										// ->where('Percent_Time', '>=', $mondayThisWeek)
										// ->where('Percent_Time', '<=', $thursdayThisWeek)
										->where('Percent_Time', $today)
										->select('Percent_Percent', 'Percent_Time', 'package_Min', 'package_Max')
										->get();
		$arrayDataResonance = [];
		$coin = 5;
		$rate = $RateCoin[$coin];
		$action = 4;
		foreach($investment as $i){
			// kiểm tra đã trả lãi hay chưa
			$checkProfits = Money::where('Money_MoneyStatus', '<>', -1)
								->where('Money_MoneyAction', $action)
								->where('Money_Time', '>=', strtotime('today'))
								->where('Money_User', $i->investment_User)
								// ->where('Money_Investment', $i->investment_ID)
								->orderByDesc('Money_Time')
								->first();
			if($checkProfits){

			    // Log::insertLogProfit($i->investment_User, 'Profit', 'Investment User:'.$i->investment_User.' Paid!');
				// continue;

			}
			$percent = self::getPercentProfit($arrPercent, $i);
			if($percent <= 0){
			    Log::insertLogProfit($i->investment_User, 'Profit', 'Investment User:'.$i->investment_User.' last week!');
				continue;
			}
	        // dd($percent, $i);
			$AmountUSD = $i->investment_Amount;
			//tính tiền lãi
			$AmountProfit = $AmountUSD * $percent / $rate;
			// dd($AmountUSD, $AmountProfit, $percent, $rate);
			//cộng tiền lãi
			$row = new Money();
			$row->Money_User = $i->investment_User;
			$row->Money_USDT = $AmountProfit;
			$row->Money_Time = $now;
			$row->Money_Comment = "Profit Daily From Investment $".number_format($i->investment_Amount,2)." (".($percent*100)."% / Day)";
			$row->Money_MoneyAction = $action;
			$row->Money_MoneyStatus = 1;
			$row->Money_Currency = $coin;
			$row->Money_Investment = $i->investment_ID;
			$row->Money_Rate = $rate;
			$row->save();
			//Update Balance
			$updateBalance = User::updateBalance($i->investment_User, $coin, $AmountProfit);
			$user = User::find($i->investment_User);
			
			self::checkCommissionResonance($i, $AmountProfit);
			// $arrayDataResonance[] = ['user_id' => $i->investment_User, 'amount_Profit' => $AmountProfit];
			
        }
        // dispatch(new CommissionResonanceJobs($arrayDataResonance));
        
        return true;
	}
	public static function checkCommissionResonance($user, $amount){
        // hoa hồng cộng hưởng
		$arrPercent = [1=>0.1, 2=>0.05, 3=>0.03];
		$currency = 5;
		$rateCurrency = app('App\Http\Controllers\System\CoinbaseController')->coinRateBuy('USDT');
		$action = 9;
        $arrParent = explode(',', $user->User_Tree);
		$arrParent = array_reverse($arrParent);
		// dd($user, $arrParent);
        for($i = 1; $i<=3; $i++){
	        if(!isset($arrParent[$i])){
		        break;
	        }
            $parentTree = User::find($arrParent[$i]);
            if(!$parentTree){
	            Log::insertLogProfit($parentTree->User_ID,'Commission Resonance', 'User ID: '.$parentTree->User_ID.' Not Found');
                continue;
            }
            
            $getInvestUser = Investment::where('investment_User', $parentTree->User_ID)->where('investment_Time', '<=', $user->investment_Time)->where('investment_Status', '<>', -1)->orderBy('investment_ID')->first();
            if(!$getInvestUser){
	            Log::insertLogProfit($parentTree->User_ID,'Commission Resonance', 'User ID: '.$parentTree->User_ID.' Dont Have Investment');
	            continue;
            }
            // if($getInvestUser->investment_Time > $investment->investment_Time){
	        //     Log::insertLogProfit($parentTree->User_ID,'Commission Resonance', 'User ID: '.$parentTree->User_ID.' Investment After This Investment ID: '.$investment->investment_ID);
	        //     continue;
            // }
			$percent = $arrPercent[$i];
			$amountCom = $amount*$percent;
	        $money = new Money();
	        $money->Money_User = $parentTree->User_ID;
	        $money->Money_USDT = $amountCom;
	        $money->Money_Time = time();
	        $money->Money_Comment = 'Resonance Commission From F'.$i.' User ID: '.$user->User_ID.' ('.($percent*100).'%)';
	        $money->Money_Currency = $currency;
	        $money->Money_MoneyAction = $action;
	        $money->Money_Address = '';
	        $money->Money_Rate = $rateCurrency;
	        $money->Money_MoneyStatus = 1;
	        $money->save();
	        //Update Balance
			$updateBalance = User::updateBalance($parentTree->User_ID, $currency, $amountCom);
        }
	    return true;
	}
    function floorp($val, $precision){
	    $mult = pow(10, $precision); // Can be cached in lookup table        
	    return floor($val * $mult) / $mult;
	}
	
}

