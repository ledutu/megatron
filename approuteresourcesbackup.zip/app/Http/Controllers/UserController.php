<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request; 
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session; 
use Illuminate\Support\Facades\Auth;
use DB;

use App\Model\User; 
use App\Model\SubAccount;
use App\Model\subAccountBalance;
use Hash;
class UserController extends Controller
{
	
	public function getLogin(){
		$noti_image = DB::table('NotificationImage')->where('Status', 0)->where('Location_Exchange', 1)->get(); 
      	return view('auth.login', compact('noti_image'));
	}
  
  	public function postLoginV2(Request $req){
        $sub = subAccount::join('users', 'user_ID', 'subAccount_User')->where('subAccount_ID', $req->username)->first();
				if(!$sub){
					return response()->json([
						'status' => false,
						'msg' => 'Account not exits',
					]);
				}
					
				if($sub->subAccount_Status == 1){
					return response()->json([
						'status' => false,
						'msg' => 'The account is locked',
					]);  
				}
		
				if (Hash::check($req->password, $sub->subAccount_Password)) {
					Session::put('sub', $sub);
					// cấp nhật session id
					subAccount::where('subAccount_ID', $req->username)->update(['subAccount_SessionID'=>Session::getId()]);
					return response()->json([
						'status' => true,
						'sub' => $sub->subAccount_ID,
						'token' => Session::getId(),	'msg' => 'Login Success!',]);           				
				}else{
					return response()->json([
						'status' => false,
						'msg' => 'Incorrect password',
					]);           
				}
    }
  
  	public function postLogin (Request $req){
			$user = User::where('User_Email', $req->username)->first();
			if(!$user){
				return redirect()->route('getLogin')->with(['flash_level'=>'error', 'flash_message'=>'Account not exits']);
			}
				
			if($user->User_Block == 1){
				return redirect()->route('getLogin')->with(['flash_level'=>'error', 'flash_message'=>'Account has been block']);
			}
			
			if (Hash::check($req->password, $user->User_Password)) {
							Session::put('user', $user);
							// cấp nhật session id
							User::where('User_Email', $req->username)->update(['user_SessionID'=>Session::getId()]);
							/*if($req->redirect) {
									return \Redirect::to(decrypt($request->redirect));
							}
							
							$checkStatistical = DB::table('statisticalSubaccount')->where('sub', Session('sub')->subAccount_ID)->wheredate('datetime', Date('Y-m-d'))->first();
							if(!$checkStatistical){
									$balance = subAccountBalance::getBalance(Session('sub')->subAccount_ID);
									DB::table('statisticalSubaccount')
										->insert(array(
											'sub'=>Session('sub')->subAccount_ID,
											'balance'=>$balance,
											'datetime'=>date('Y-m-d H:i:s'),
										));
							}*/
				return redirect()->route('getExchange')->with(['flash_level'=>'success', 'flash_message'=>'Login Success!']);

				
			}else{
				return redirect()->route('getLogin')->with(['flash_level'=>'error', 'flash_message'=>'Incorrect password']);
			}
    }
  
  	public function getLogout(Request $req){
      	Session::forget('user');
        return redirect()->route('getLogin');
    }
	
	
}

