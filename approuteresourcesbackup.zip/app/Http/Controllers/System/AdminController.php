<?php
namespace App\Http\Controllers\System;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Controllers\System\CoinbaseController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Session;

class AdminController extends Controller
{
    public function getMember(){
        return view('system.admin.User');
    }
    public function getWallet(){
        return view('system.admin.Wallet');
    }
    public function getTrade(){
        return view('system.admin.Trade');
    }
    public function getKYC(){
        return view('system.admin.KYC');
    }
  
}
