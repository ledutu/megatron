<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request; 
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session; 
use Illuminate\Support\Facades\Auth;
use DB;

use App\Model\User;
use App\Model\subAccount;
use App\Model\GameBet;
use App\Model\GameCoin;
use App\Model\LogAdmin;



class GameController extends Controller{
	
	
	
	public function getResult(Request $req){
		$fund = DB::table('GameFund')->where('GameFund_symbol', 'BTCUSDT')->first();
		$symbol = array(
			'BCHUSDT' => array(
				'put' => 0,
				'call' => 0
			),
			'BNBUSDT' => array(
				'put' => 0,
				'call' => 0
			),
			'EOSUSDT' => array(
				'put' => 0,
				'call' => 0
			),
			'DASHUSDT' => array(
				'put' => 0,
				'call' => 0
			),
			'LTCUSDT' => array(
				'put' => 0,
				'call' => 0
			),
			'ETHUSDT' => array(
				'put' => 0,
				'call' => 0
			),
			'BTCUSDT' => array(
				'put' => 0,
				'call' => 0
			)
		);
		
		$betList = GameBet::where('GameBet_Status', 0)
							->where('GameBet_SubAccountType', 0)
							->whereIn('GameBet_SubAccountLevel', [0,5])
							->get();
		
		$total = 0;
		foreach($betList as $v){
          	if($v->GameBet_Currency == 3){
              $amounttemp = $v->GameBet_Amount;
            }else{
              $amounttemp = $v->GameBet_Amount/130;
            }
			$total += $amounttemp;
			if($v->GameBet_Type == 'buy'){

				$symbol[$v->GameBet_Symbol]['call'] += $amounttemp;
			}else{

				$symbol[$v->GameBet_Symbol]['put'] += $amounttemp;
			}
			
		}

		$A = 0;
		foreach($symbol as $v){
			$A += abs($v['call'] - $v['put']);
		}
		

		$B = $fund->GameFund_fundReal - ($total*0.05);

		$rand = rand(0,99);
		
		if($A < $B){
			// kết qủa tự nhiên
			
			return response()->json(['status' => true]);
		}else{

			// lấy những cặp tiền đang đánh
			$sql = GameBet::select('GameBet_Symbol')->where('GameBet_Status', 0)->groupBy('GameBet_Symbol')->get();

			
			foreach($sql as $v){

				$game = LogAdmin::where('adminLogGame_Type', $v->GameBet_Symbol)->where('adminLogGame_Status', 0)->first();
				if(!$game){
					if($symbol[$v->GameBet_Symbol]['call'] < $symbol[$v->GameBet_Symbol]['put']){
						// call thắng
						//echo '<pre>symbol '.$v->GameBet_Symbol.' call Win </pre>';
						if($rand<=50){
							$closeFinal = self::setResult('AminQ', $v->GameBet_Symbol, 1);	
						}else{
							$closeFinal = self::setResult('AminQ', $v->GameBet_Symbol, 1);	
						}
						
					}else{
						// put thắng
						//echo '<pre>symbol '.$v->GameBet_Symbol.' put Win </pre>';
						if($rand<=50){
							$closeFinal = self::setResult('AminQ', $v->GameBet_Symbol, 0);	
						}else{
							$closeFinal = self::setResult('AminQ', $v->GameBet_Symbol, 0);
						}
						
					}
				}
				
				 
			}
			return response()->json(['status' => true]);
			
		}
		
		
	}
	
	public function setResultByAdmin(Request $req){
		//dd(file_get_contents('http://localhost:8888/exchangefibo/public/getresult?symbol=BTCUSDT&game=21300'));
		$user = DB::table('users')->where('user_ID', $req->user)->first();
		/*if($user->User_Level != 5){
			return response()->json(['status' => false]);
		}*/
		$game = LogAdmin::where('adminLogGame_Type', $req->symbol)->where('adminLogGame_Status', 0)->first();
		
		
		
		if(!$game){
			if($req->win == 1){
				
				$closeFinal = self::setResult($req->user, $req->symbol, 1);
			}else{
				$closeFinal = self::setResult($req->user, $req->symbol, 0);
			}
			return response()->json(['status' => true,'point' => $closeFinal]);
		}
		return response()->json(['status' => false]);
	}
	
	public function setResult($user, $symbol, $win){
		
		// lấy lịch sử cuối cũng của nến
		$result = GameCoin::where('GameCoin_Order', 1)->orderBy('GameCoin_Time', 'DESC')->first();
		// dd($symbol,$win, $result);
		
		$close = $result->GameCoin_Data[$symbol]['close'];

		$closePecent = self::random_float(10,20);
 
		$point = ($close * $closePecent)/1000;
		if($win == 1){
			if($symbol == 'BTCUSDT'){
				$closeFinal = $close+(rand(20, 40)/10);
			}else{
				$closeFinal = $close+$point;
			}
			$arrayInsert = array(
				'adminLogGame_Close' => $closeFinal,
				'adminLogGame_Open' => $result->GameCoin_Data[$symbol]['close'],
				'adminLogGame_Type' => $symbol,
				'adminLogGame_User' => $user,
				'adminLogGame_Status' => 0,
				'adminLogGame_Log' => 'Fund BUY win'
			);
			if(LogAdmin::addLog($arrayInsert)){
				return $closeFinal;
			}
		}elseif($win == 0){
			if($symbol == 'BTCUSDT'){
				$closeFinal = $close-(rand(20, 40)/10);
			}else{
				$closeFinal = $close-$point;
			}
			$arrayInsert = array(
				'adminLogGame_Close' => $closeFinal,
				'adminLogGame_Open' => $result->GameCoin_Data[$symbol]['close'],
				'adminLogGame_Type' => $symbol,
				'adminLogGame_User' => $user,
				'adminLogGame_Status' => 0,
				'adminLogGame_Log' => 'Fund SELL win'
			);
			if(LogAdmin::addLog($arrayInsert)){
				return $closeFinal;
			}
			
		}else{
			$closeFinal = $close;
			$arrayInsert = array(
				'adminLogGame_Close' => $closeFinal,
				'adminLogGame_Open' => $result->GameCoin_Data[$symbol]['close'],
				'adminLogGame_Type' => $symbol,
				'adminLogGame_User' => $user,
				'adminLogGame_Status' => 0,
				'adminLogGame_Log' => 'Fund Draw'
			);
          	
			if(LogAdmin::addLog($arrayInsert)){
				return $closeFinal;
			}
			
		}
	
		
		
	}
	
	
	
	function getCLosePoint($point){
		$closeFinal = $point + ($point * self::random_float(0,10))/100;
		return round($closeFinal, 2);
	}
	
	function random_float($min,$max) {
		$randomFloat = rand($min, $max) / 100;
		return $randomFloat+0.01;

	}
	
}
