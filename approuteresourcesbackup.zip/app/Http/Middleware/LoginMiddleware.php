<?php

namespace App\Http\Middleware;

use Closure;
use App\Model\SubAccount;
use Session;
use Illuminate\Support\Facades\URL;
use Redirect;


class LoginMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
		

        if(session('user')) {
            // dd(3123);
            return $next($request);
            
        }
        return redirect()->route('getLogin',['redirect'=>encrypt(\Request::fullUrl())])->with(['flash_level'=>'error', 'flash_message'=>'Please Login!']);

    }
}
