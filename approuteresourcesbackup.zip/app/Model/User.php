<?php

namespace App\Model;


use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

use DB;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'User_Name', 'User_Password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'User_Password'
    ];
    
    protected $primaryKey = 'User_ID';
    
    public $timestamps = false;
    
	
	public static function checkAccountByUser($u){
		$user = User::where('User_Name', $u)->first();
		if(!$user){
			return null;
		}
		return $user;
	}
	
	public static function checkAccountByEmail($e){
		$user = User::where('User_Email', $e)->first();
		if(!$user){
			return null;
		}
		return $user;
	}
  
  	public static function getBalance($user, $currency){
      
		$balanceSub = 0;
	

		$balanceCheck = DB::table('balance_game')->where('user', $user)->where('currency', $currency)->orderBy('id', 'DESC')->first();


		if(!$balanceCheck){
			$balanceSub += 0;
			
		}else{
				
			$bet = GameBet::where('GameBet_SubAccountUser', $user)
							->whereIn('GameBet_Status', [0,1,2,3])
              				->where('GameBet_Currency', $currency)
							->where('GameBet_datetime', '>=', $balanceCheck->time)
							->sum('GameBet_AmountWin');

			$balanceSub = $balanceCheck->amount+$bet;

		}
		return $balanceSub;
	}
    
    
}

