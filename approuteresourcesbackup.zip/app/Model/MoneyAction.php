<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class MoneyAction extends Model
{
    //
    protected $table = 'moneyaction';
}
