<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;
use Carbon\Carbon;
use App\Model\GameBet;

class GameBalance extends Model{
    protected $table = "balance_game";
    
    protected $fillable = ['id','user', 'action', 'amount', 'comment', 'time', 'currency', 'status'];

	public $timestamps = false;
	
	public static function getBalance($user, $currency){
		$balance = 0;

		$balanceCheck = GameBalance::where('user', $user)->where('status', 1)->orderBy('id', 'DESC')->where('currency', $currency)->first();
		

		if(!$balanceCheck){
			$balance += 0;
			
		}else{
				
			$bet = GameBet::where('GameBet_SubAccountUser', $user)
							->whereIn('GameBet_Status', [0,1,2,3])
							->where('GameBet_datetime', '>=', $balanceCheck->time)
							->sum('GameBet_AmountWin');
			$balance = $balanceCheck->balance+$bet;

		}
		return $balance;
	}
	
	
}
