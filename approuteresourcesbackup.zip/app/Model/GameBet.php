<?php

namespace App\Model;

use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\Model;
use Jenssegers\Mongodb\Eloquent\Model as Eloquent;
use Carbon\Carbon;


use DB;
class GameBet extends Eloquent
{
	protected $connection = 'mongodb';
    protected $collection = 'gamebets';
    protected $fillable = ['_id','GameBet_SubAccount','GameBet_SubAccountLevel','GameBet_SubAccountType','GameBet_SubAccountUser','GameBet_SubAccountEndBalance','GameBet_Type','GameBet_Symbol','GameBet_Amount','GameBet_Fund','GameBet_Status','GameBet_Log','GameBet_IB','GameBet_Notification', 'GameBet_CopyTrade', 'GameBet_datetime'];
    
    public $timestamps = true;
    
/*
    public function Action(){
	    return $this->hasMany('App\Model3\ActionName','Action_ActionID');
    }
*/
	
	
}
