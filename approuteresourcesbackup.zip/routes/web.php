<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('login', 'UserController@getLogin')->name('getLogin');
Route::get('logout', 'UserController@getLogout')->name('getLogout');
Route::post('login', 'UserController@postLogin')->name('postLogin');
Route::post('api-login', 'UserController@postLoginV2')->name('postLoginV2');
Route::get('api-history', 'ExchangeController@getHistoryV2')->name('getHistoryV2');

Route::group(['middleware'=>['LoginMiddleware']], function(){
  //exchange

  Route::get('/', 'ExchangeController@getExchange')->name('getExchange');
  
  Route::get('history', 'ExchangeController@getHistory')->name('getHistory');
  Route::get('statistical', 'ExchangeController@getStatistical')->name('getStatistical');
  //wallet
  Route::get('wallet','System\WalletController@getWallet')->name('getWallet');
  Route::post('withdraw','System\WalletController@postWithdraw')->name('postWithdraw');
  Route::get('coin','System\CoinbaseController@getAddress')->name('getCoin');
  //dashboard
  Route::get('dashboard','System\DashboardController@getDashboard')->name('getDashboard');

  //agency
  Route::get('agency','System\AgencyController@getAgency')->name('getAgency');


});

Route::group(['middleware'=>['LoginMiddleware'], 'prefix' => 'admin'], function(){
  Route::get('member', 'System\AdminController@getMember')->name('admin.getMember');
  Route::get('wallet', 'System\AdminController@getWallet')->name('admin.getWallet');
  
  Route::get('trade', 'System\AdminController@getTrade')->name('admin.getTrade');
  Route::get('kyc', 'System\AdminController@getKYC')->name('admin.getKYC');

});

Route::get('getresult', 'GameController@getResult')->name('getResult');
Route::get('money', 'GameController@getMoney')->name('getMoney');
Route::get('setResultByAdmin', 'GameController@setResultByAdmin')->name('setResultByAdmin');
Route::get('test', 'Controller@testfunction')->name('getTest');
